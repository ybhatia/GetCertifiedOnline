package com.cg.gco.feedback.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.gco.feedback.entity.FeedbackEntity;

public interface FeedbackDao extends JpaRepository<FeedbackEntity, Long>{
	
	Boolean existsByTrainerIdAndCourseId(Long trainerId, Long CourseId);
	
	Boolean existsByTrainerId(Long trainerId);
	
	Boolean existsByCourseId(Long CourseId);
	
	@Query(value = "Select * from feedback where course_id = ?", nativeQuery = true)
	List<FeedbackEntity> getFeedbackByCourse(Long courseId);

	@Query(value = "Select * from feedback where trainer_id = ?", nativeQuery = true)
	List<FeedbackEntity> getFeedbackByTrainer(Long trainerId);
	

}
