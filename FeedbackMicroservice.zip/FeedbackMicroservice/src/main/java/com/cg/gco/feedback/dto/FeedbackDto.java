package com.cg.gco.feedback.dto;

public class FeedbackDto {
	
	private Long id;
	private TrainerDto trainer;
	private CourseDto course;
	private Long commSkill;
	private Long doubtClarity;
	private Long timeMgmt;
	private Long studyMaterial;
	private String comment;
	
	
	public FeedbackDto() {
		super();
	}

	public FeedbackDto(Long id, TrainerDto trainer, CourseDto course, Long commSkill, Long doubtClarity, Long timeMgmt,
			Long studyMaterial, String comment) {
		super();
		this.id = id;
		this.trainer = trainer;
		this.course = course;
		this.commSkill = commSkill;
		this.doubtClarity = doubtClarity;
		this.timeMgmt = timeMgmt;
		this.studyMaterial = studyMaterial;
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "FeedbackDto [id=" + id + ", trainer=" + trainer + ", course=" + course + ", commSkill=" + commSkill
				+ ", doubtClarity=" + doubtClarity + ", timeMgmt=" + timeMgmt + ", studyMaterial=" + studyMaterial
				+ ", comment=" + comment + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TrainerDto getTrainer() {
		return trainer;
	}

	public void setTrainer(TrainerDto trainer) {
		this.trainer = trainer;
	}

	public CourseDto getCourse() {
		return course;
	}

	public void setCourse(CourseDto course) {
		this.course = course;
	}

	public Long getCommSkill() {
		return commSkill;
	}

	public void setCommSkill(Long commSkill) {
		this.commSkill = commSkill;
	}

	public Long getDoubtClarity() {
		return doubtClarity;
	}

	public void setDoubtClarity(Long doubtClarity) {
		this.doubtClarity = doubtClarity;
	}

	public Long getTimeMgmt() {
		return timeMgmt;
	}

	public void setTimeMgmt(Long timeMgmt) {
		this.timeMgmt = timeMgmt;
	}

	public Long getStudyMaterial() {
		return studyMaterial;
	}

	public void setStudyMaterial(Long studyMaterial) {
		this.studyMaterial = studyMaterial;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	
	

}
