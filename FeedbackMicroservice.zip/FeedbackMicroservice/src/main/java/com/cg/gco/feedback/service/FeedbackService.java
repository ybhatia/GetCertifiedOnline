package com.cg.gco.feedback.service;

import java.util.List;

import com.cg.gco.feedback.dto.CourseDto;
import com.cg.gco.feedback.dto.FeedbackDto;
import com.cg.gco.feedback.dto.TrainerDto;
import com.cg.gco.feedback.dto.request.AddFeedbackRequest;
import com.cg.gco.feedback.entity.FeedbackEntity;
import com.cg.gco.feedback.exception.BadRequestException;
import com.cg.gco.feedback.exception.NotFoundException;

public interface FeedbackService {
	
	public void addCertification(AddFeedbackRequest addFeedbackRequest) throws NotFoundException, BadRequestException;
	
//	public FeedbackDto getFeedbackByCourseId(Long courseId) throws NotFoundException;
//	public FeedbackDto getFeedbackByTrainerId(Long trainerId) throws NotFoundException;
	
	public List<FeedbackEntity> getFeedbackByCourse(Long courseId) throws NotFoundException;
	public List<FeedbackEntity> getFeedbackByTrainer(Long trainerId) throws NotFoundException;


	List<FeedbackDto> getFeedback();
	
	List<TrainerDto> getFaculties();
	List<CourseDto> getCourses();

}
