package com.cg.gco.feedback.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.gco.feedback.dto.CourseDto;
import com.cg.gco.feedback.dto.FeedbackDto;
import com.cg.gco.feedback.dto.TrainerDto;
import com.cg.gco.feedback.dto.request.AddFeedbackRequest;
import com.cg.gco.feedback.dto.response.SuccessResponse;
import com.cg.gco.feedback.entity.FeedbackEntity;
import com.cg.gco.feedback.exception.BadRequestException;
import com.cg.gco.feedback.exception.NotFoundException;
import com.cg.gco.feedback.service.FeedbackService;

@RestController
@RequestMapping("/feedback")
@CrossOrigin("http://localhost:4200")
public class FeedbackController {
	
	@Autowired
	FeedbackService feedbackService;
	
	@PostMapping("/addfeedback")
	public SuccessResponse addFeedback(@RequestBody AddFeedbackRequest addfeedbackRequest)
			throws BadRequestException, NotFoundException {
		System.out.println(addfeedbackRequest.toString());
		feedbackService.addCertification(addfeedbackRequest);
		return new SuccessResponse(true,"Successfully added new feedback");
	}
	
//	End point to get all feedback
	@GetMapping("/allfeedback")
	public List<FeedbackDto> getFeedback() {
		System.out.println(feedbackService.getFeedback().toString());
		return feedbackService.getFeedback();
	}
	
//	End point to get feedback by course id
//	@GetMapping("/feedbackbycourseid/{courseId}")
//	public FeedbackDto getFeedbackByCourse(@PathVariable Long courseId) throws NotFoundException {
//		System.out.println("CHINMAYEE NANDAKISHOR MANJAREKAR");
//		return feedbackService.getFeedbackByCourseId(courseId);
//	} 
	
	@GetMapping("/feedbackbycourseid/{courseId}")
	public ResponseEntity<List<FeedbackEntity>> getFeedbackByCourse(@PathVariable Long courseId) throws NotFoundException{
		List<FeedbackEntity> feedback = feedbackService.getFeedbackByCourse(courseId);
		return new ResponseEntity<>(feedback, HttpStatus.OK);	
	}

//	End point to get feedback by trainer id
//	@GetMapping("/feedbackbytrainerid/{trainerId}")
//	public FeedbackDto getFeedbackByTrainer(@PathVariable Long trainerId) throws NotFoundException {
//		return feedbackService.getFeedbackByTrainerId(trainerId);
//	} 	
	
	@GetMapping("/feedbackbytrainerid/{trainerId}")
	public ResponseEntity<List<FeedbackEntity>> getFeedbackByTrainer(@PathVariable Long trainerId) throws NotFoundException{
		List<FeedbackEntity> feedback = feedbackService.getFeedbackByTrainer(trainerId);
		return new ResponseEntity<>(feedback, HttpStatus.OK);
	}
	
//	End Point to get all the faculties.
	@GetMapping("/trainers")
	public List<TrainerDto> getFaculties() {
		System.out.println(feedbackService.getFaculties().toString());
		return feedbackService.getFaculties();
	}
	
//	End Point to get all the courses.	
	@GetMapping("/courses")
	public List<CourseDto> getCourses() {
		List<CourseDto> check=feedbackService.getCourses();
		System.out.println(check.toString());
		return check;
	}


}
