package com.cg.gco.feedback.dto.request;

public class AddFeedbackRequest {
	
	private Long trainerId;
	private Long courseId;
	private Long commSkill;
	private Long doubtClarity;
	private Long timeMgmt;
	private Long studyMaterial;
	private String comment;
	
	
	public AddFeedbackRequest() {
		super();
	}


	public AddFeedbackRequest(Long trainerId, Long courseId, Long commSkill, Long doubtClarity, Long timeMgmt,
			Long studyMaterial, String comment) {
		super();
		this.trainerId = trainerId;
		this.courseId = courseId;
		this.commSkill = commSkill;
		this.doubtClarity = doubtClarity;
		this.timeMgmt = timeMgmt;
		this.studyMaterial = studyMaterial;
		this.comment = comment;
	}


	public Long getTrainerId() {
		return trainerId;
	}


	public void setTrainerId(Long trainerId) {
		this.trainerId = trainerId;
	}


	public Long getCourseId() {
		return courseId;
	}


	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}


	public Long getCommSkill() {
		return commSkill;
	}


	public void setCommSkill(Long commSkill) {
		this.commSkill = commSkill;
	}


	public Long getDoubtClarity() {
		return doubtClarity;
	}


	public void setDoubtClarity(Long doubtClarity) {
		this.doubtClarity = doubtClarity;
	}


	public Long getTimeMgmt() {
		return timeMgmt;
	}


	public void setTimeMgmt(Long timeMgmt) {
		this.timeMgmt = timeMgmt;
	}


	public Long getStudyMaterial() {
		return studyMaterial;
	}


	public void setStudyMaterial(Long studyMaterial) {
		this.studyMaterial = studyMaterial;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	

}
