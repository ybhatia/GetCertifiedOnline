package com.cg.gco.feedback.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "feedback")
public class FeedbackEntity extends BaseEntity{
	
	@ManyToOne
	@JoinColumn(name = "trainer_id", nullable = false)
	private TrainerEntity trainer;

	@ManyToOne
	@JoinColumn(name = "course_id", nullable = false)
	private CourseEntity course;
	
	@Column(name="comm_skill")
	private Long commSkill;
	
	@Column(name="doubt_clarity")
	private Long doubtClarity;
	
	@Column(name="time_mgmt")
	private Long timeMgmt;
	
	@Column(name="study_material")
	private Long studyMaterial;
	
	@Column(name="comment")
	private String comment;

	public TrainerEntity getTrainer() {
		return trainer;
	}

	public void setTrainer(TrainerEntity trainer) {
		this.trainer = trainer;
	}

	public CourseEntity getCourse() {
		return course;
	}

	public void setCourse(CourseEntity course) {
		this.course = course;
	}

	public Long getCommSkill() {
		return commSkill;
	}

	public void setCommSkill(Long commSkill) {
		this.commSkill = commSkill;
	}

	public Long getDoubtClarity() {
		return doubtClarity;
	}

	public void setDoubtClarity(Long doubtClarity) {
		this.doubtClarity = doubtClarity;
	}

	public Long getTimeMgmt() {
		return timeMgmt;
	}

	public void setTimeMgmt(Long timeMgmt) {
		this.timeMgmt = timeMgmt;
	}

	public Long getStudyMaterial() {
		return studyMaterial;
	}

	public void setStudyMaterial(Long studyMaterial) {
		this.studyMaterial = studyMaterial;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	

}
