package com.cg.gco.feedback.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.gco.feedback.entity.TrainerEntity;

public interface TrainerDao extends JpaRepository<TrainerEntity, Long>{

}
