package com.cg.gco.feedback.exception;

public class NotFoundException extends Exception{
	
	private static final long serialVersionUID = -3210733846262373787L;
	private static String defaultMessage = "Resource not found";

	public NotFoundException() {
		super(defaultMessage);
	}
	
	public NotFoundException(String errorMessage) {
		super(errorMessage);
	}

}
