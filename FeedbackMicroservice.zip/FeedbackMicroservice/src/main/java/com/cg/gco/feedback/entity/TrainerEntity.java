package com.cg.gco.feedback.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "trainers")
public class TrainerEntity extends BaseEntity{
	
	@Column
	private String trainerName;

	@Column
	private String trainerSkill;

	public TrainerEntity() {
	}

	public TrainerEntity(String trainerName, String trainerSkill, Long id) {
		this.trainerName = trainerName;
		this.trainerSkill = trainerSkill;
		this.setId(id);
	}


	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getTrainerSkill() {
		return trainerSkill;
	}

	public void setTrainerSkill(String trainerSkill) {
		this.trainerSkill = trainerSkill;
	}

}
