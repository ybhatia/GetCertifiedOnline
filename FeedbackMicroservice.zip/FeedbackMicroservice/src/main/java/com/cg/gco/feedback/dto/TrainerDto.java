package com.cg.gco.feedback.dto;

public class TrainerDto {
	
	private Long id;
	
	private String trainerName;

	public TrainerDto() {
	}

	public TrainerDto(Long id, String trainerName, String trainerSkill) {
		super();
		this.id = id;
		this.trainerName = trainerName;
	}

	
	@Override
	public String toString() {
		return "TrainerDto [id=" + id + ", trainerName=" + trainerName + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}


}
