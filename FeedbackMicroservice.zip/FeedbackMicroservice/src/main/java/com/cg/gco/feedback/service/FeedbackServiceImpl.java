package com.cg.gco.feedback.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gco.feedback.dao.CourseDao;
import com.cg.gco.feedback.dao.FeedbackDao;
import com.cg.gco.feedback.dao.TrainerDao;
import com.cg.gco.feedback.dto.CourseDto;
import com.cg.gco.feedback.dto.FeedbackDto;
import com.cg.gco.feedback.dto.TrainerDto;
import com.cg.gco.feedback.dto.request.AddFeedbackRequest;
import com.cg.gco.feedback.entity.CourseEntity;
import com.cg.gco.feedback.entity.FeedbackEntity;
import com.cg.gco.feedback.entity.TrainerEntity;
import com.cg.gco.feedback.exception.BadRequestException;
import com.cg.gco.feedback.exception.NotFoundException;

@Service
public class FeedbackServiceImpl implements FeedbackService{
	
	@Autowired
	private FeedbackDao feedbackDao;
	
	@Autowired
	private TrainerDao trainerDao;

	@Autowired
	private CourseDao courseDao;
	
	FeedbackDto convert(FeedbackEntity feedback) {
		if (feedback != null) {
			FeedbackDto feedbackDto = new FeedbackDto();
		BeanUtils.copyProperties(feedback, feedbackDto);
		CourseDto courseDto = new CourseDto();
		BeanUtils.copyProperties(feedback.getCourse(), courseDto);
		feedbackDto.setCourse(courseDto);
		TrainerDto trainerDto = new TrainerDto();
		BeanUtils.copyProperties(feedback.getTrainer(), trainerDto);
		feedbackDto.setTrainer(trainerDto);
		return feedbackDto;
		}
		return null;
	}

//	Add Feedback
	@Override
	public void addCertification(AddFeedbackRequest addFeedbackRequest) throws NotFoundException, BadRequestException {
		
		if (addFeedbackRequest.getTrainerId() == null) {
			throw new BadRequestException("TrainerId cannot be null.");
		} else if (addFeedbackRequest.getCourseId() == null) {
			throw new BadRequestException("CourseId cannot be null.");
		} else if (addFeedbackRequest.getCommSkill() == null) {
			throw new BadRequestException("commSkill cannot be null.");
		} else if (addFeedbackRequest.getDoubtClarity() == null) {
			throw new BadRequestException("doubtClarity cannot be null.");
		}else if (addFeedbackRequest.getTimeMgmt() == null) {
			throw new BadRequestException("timeMgmt cannot be null.");
		}else if (addFeedbackRequest.getStudyMaterial() == null) {
			throw new BadRequestException("studyMaterial cannot be null.");
		}else if (addFeedbackRequest.getComment() == null) {
			throw new BadRequestException("comments cannot be null.");
		}
		
//		Validate Trainer
		Optional<TrainerEntity> trainer = trainerDao.findById(addFeedbackRequest.getTrainerId());
		if (!trainer.isPresent()) {
			throw new NotFoundException("Trainer not found");
		}
		
//		Validate Course
		Optional<CourseEntity> course = courseDao.findById(addFeedbackRequest.getCourseId());
		if (!course.isPresent()) {
			throw new NotFoundException("Course not found");
		}
		
		FeedbackEntity feedback = new FeedbackEntity();
		feedback.setTrainer(trainer.get());
		feedback.setCourse(course.get());
		feedback.setCommSkill(addFeedbackRequest.getCommSkill());
		feedback.setDoubtClarity(addFeedbackRequest.getDoubtClarity());
		feedback.setTimeMgmt(addFeedbackRequest.getTimeMgmt());
		feedback.setStudyMaterial(addFeedbackRequest.getStudyMaterial());
		feedback.setComment(addFeedbackRequest.getComment());
		feedbackDao.save(feedback);
	}

//	Get feedback by courseId
//	@Override
//	public FeedbackDto getFeedbackByCourseId(Long courseId) throws NotFoundException {
//		Optional<FeedbackEntity> feedbackOptional = feedbackDao.findById(courseId);
//		if (!feedbackOptional.isPresent()) {			
//			throw new NotFoundException("Feedback by courseId not found");
//		}
//		return convert(feedbackOptional.get());
//	}

	@Override
	public List<FeedbackEntity> getFeedbackByCourse(Long courseId) throws NotFoundException {
		List<FeedbackEntity> optional = feedbackDao.getFeedbackByCourse(courseId);
		if(optional.isEmpty()) {
			throw new NotFoundException(String.format("Sorry, Course Id: %d Not Found", courseId));
		}
		return optional;
			
	}
	
	
//	Get feedback by trainerId
//	@Override
//	public FeedbackDto getFeedbackByTrainerId(Long trainerId) throws NotFoundException {
//		Optional<FeedbackEntity> feedbackOptional = feedbackDao.findById(trainerId);
//		if (!feedbackOptional.isPresent()) {
//			throw new NotFoundException("Feedback by trainerId not found");
//		}
//		return convert(feedbackOptional.get());
//	}
	
	@Override
	public List<FeedbackEntity> getFeedbackByTrainer(Long trainerId) throws NotFoundException {
		List<FeedbackEntity> optional = feedbackDao.getFeedbackByTrainer(trainerId);
		if(optional.isEmpty()) {
			throw new NotFoundException(String.format("Sorry, Trainer Id: %d Not Found", trainerId));
		}
		return optional;
	}

//	Get All Feedback
	@Override
	public List<FeedbackDto> getFeedback() {
		List<FeedbackEntity> feedbackList = feedbackDao.findAll();
		if (!feedbackList.isEmpty()) {
			List<FeedbackDto> certificationDtoList = new ArrayList<FeedbackDto>();
			for (FeedbackEntity certification : feedbackList) {
				certificationDtoList.add(convert(certification));
			}
			return certificationDtoList;
		}
		return null;
	}

//	Get All Faculties
	@Override
	public List<TrainerDto> getFaculties() {
		List<TrainerEntity> trainerList = trainerDao.findAll();
		if (!trainerList.isEmpty()) {
			List<TrainerDto> trainerDtoList = new ArrayList<TrainerDto>();
			for (TrainerEntity trainerEntity : trainerList) {
				TrainerDto trainerDto = new TrainerDto();
				BeanUtils.copyProperties(trainerEntity, trainerDto);
				trainerDtoList.add(trainerDto);
			}
			return trainerDtoList;
		}
		return null;
	}

//	Get All Courses
	@Override
	public List<CourseDto> getCourses() {
		List<CourseEntity> courseList = courseDao.findAll();
		if (!courseList.isEmpty()) {
			List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
			for (CourseEntity courseEntity : courseList) {
				CourseDto courseDto = new CourseDto();
				BeanUtils.copyProperties(courseEntity, courseDto);
				courseDtoList.add(courseDto);
			}
			
			return courseDtoList;
		}
		return null;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
