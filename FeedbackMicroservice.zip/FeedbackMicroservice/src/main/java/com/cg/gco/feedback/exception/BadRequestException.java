package com.cg.gco.feedback.exception;

public class BadRequestException extends Exception{
	
	private static final long serialVersionUID = 1L;
	private static String defaultMessage = "Bad Request";

	public BadRequestException() {
		super(defaultMessage);
	}

	public BadRequestException(String errorMessage) {
        super(errorMessage);
    }

}
