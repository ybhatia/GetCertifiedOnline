package com.cg.gco.adminSupport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
