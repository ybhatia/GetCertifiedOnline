package com.cg.gco.adminSupport.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import com.cg.gco.adminSupport.validation.Validation;

public class TestTrainingId {

	Validation validation = new Validation();

	@Test
	public void testTrainingIdBlank() {
		boolean isIdValid = validation.isValidId("");
		assertFalse(isIdValid);
	}

	@Test
	public void testTrainingIdWithNumber() {
		boolean isIdValid = validation.isValidId("121");
		assertTrue(isIdValid);
	}

	@Test
	public void testTrainingIdWithFloatValue() {
		boolean isIdValid = validation.isValidId("121.5");
		assertFalse(isIdValid);
	}

	@Test
	public void testTrainingIdWithCharacter() {
		boolean isIdValid = validation.isValidId("abc");
		assertFalse(isIdValid);
	}

	@Test
	public void testTrainingIdWithSpecialCharacter() {
		boolean isIdValid = validation.isValidId("1@1");
		assertFalse(isIdValid);
	}

	@Test
	public void testTrainingIdWithNumberAndCharacter() {
		boolean isIdValid = validation.isValidId("1a1");
		assertFalse(isIdValid);
	}

}
