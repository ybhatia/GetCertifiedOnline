package com.cg.gco.adminSupport.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class CertificationExamDto {

	private Integer examId;
	private Integer studentId;
	private LocalDate examDate;
	private LocalTime examStartTime;
	private LocalTime examEndTime;
	private Integer examDuration;
	private String examSlot;

	public CertificationExamDto() {
		super();
	}

	public CertificationExamDto(Integer examId, Integer studentId, LocalDate examDate, LocalTime examStartTime,
			LocalTime examEndTime, Integer examDuration, String examSlot) {
		super();
		this.examId = examId;
		this.studentId = studentId;
		this.examDate = examDate;
		this.examStartTime = examStartTime;
		this.examEndTime = examEndTime;
		this.examDuration = examDuration;
		this.examSlot = examSlot;
	}

	public Integer getExamId() {
		return examId;
	}

	public void setExamId(Integer examId) {
		this.examId = examId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public LocalTime getExamStartTime() {
		return examStartTime;
	}

	public void setExamStartTime(LocalTime examStartTime) {
		this.examStartTime = examStartTime;
	}

	public LocalTime getExamEndTime() {
		return examEndTime;
	}

	public void setExamEndTime(LocalTime examEndTime) {
		this.examEndTime = examEndTime;
	}

	public Integer getExamDuration() {
		return examDuration;
	}

	public void setExamDuration(Integer examDuration) {
		this.examDuration = examDuration;
	}

	public String getExamSlot() {
		return examSlot;
	}

	public void setExamSlot(String examSlot) {
		this.examSlot = examSlot;
	}

	@Override
	public String toString() {
		return "CertificationExamDto [examId=" + examId + ", studentId=" + studentId + ", examDate=" + examDate
				+ ", examStartTime=" + examStartTime + ", examEndTime=" + examEndTime + ", examDuration=" + examDuration
				+ ", examSlot=" + examSlot + "]";
	}

}
