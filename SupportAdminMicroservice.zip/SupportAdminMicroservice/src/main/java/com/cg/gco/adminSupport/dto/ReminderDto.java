package com.cg.gco.adminSupport.dto;

import java.sql.Date;
import java.time.LocalDate;

public class ReminderDto {
	private String studentName;
	private String emailId;
//	private String subjectOfMail;
	private String message;
	private LocalDate examDate;

	public ReminderDto() {
		super();
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}
}

	