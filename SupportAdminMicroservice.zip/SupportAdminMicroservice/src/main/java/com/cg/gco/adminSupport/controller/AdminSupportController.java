package com.cg.gco.adminSupport.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.gco.adminSupport.configuration.EmailConfig;
import com.cg.gco.adminSupport.dto.ReminderDto;
import com.cg.gco.adminSupport.dto.StudentDto;
import com.cg.gco.adminSupport.entity.CertificationExamEntity;
import com.cg.gco.adminSupport.entity.StudentEntity;
import com.cg.gco.adminSupport.entity.TrainingEntity;
import com.cg.gco.adminSupport.exception.StudentNotFoundException;
import com.cg.gco.adminSupport.service.AdminSupportService;

@RestController
@RequestMapping("/adminSupport")
@CrossOrigin("*")
public class AdminSupportController {

	@Autowired
	private EmailConfig emailConfig;
	
	@Autowired
	private AdminSupportService adminSupportService;
	final static Logger logger = LoggerFactory.getLogger(AdminSupportController.class);

	@Autowired
	RestTemplate restTemplate;
	
	public AdminSupportController(EmailConfig emailConfig) {
		this.emailConfig = emailConfig;
	}

	@GetMapping("/studentDetailsByStudentId/{studentId}")
	public ResponseEntity<StudentEntity> getStudentDetailsByStudentId(@PathVariable Integer studentId) {
		StudentEntity student = adminSupportService.getStudentById(studentId);
		return new ResponseEntity<>(student, HttpStatus.OK);
	}

	@GetMapping("/trainingDetailsByStudentId/{studentId}")
	public ResponseEntity<List<TrainingEntity>> getTrainingDetailsByStudentId(@PathVariable Integer studentId) {
		List<TrainingEntity> training = adminSupportService.getTrainingDetailsByStudentId(studentId);
		return new ResponseEntity<>(training, HttpStatus.OK);
	}

	@GetMapping("/examDetailsByStudentId/{studentId}")
	public ResponseEntity<List<CertificationExamEntity>> getExamDetailsByStudentId(@PathVariable Integer studentId) {
		List<CertificationExamEntity> exam = adminSupportService.searchExamDetailsByStudentId(studentId);
		return new ResponseEntity<>(exam, HttpStatus.OK);
	}
	

	
	@GetMapping("/getAllStudentDetails")
	public ResponseEntity<List<StudentEntity>> getAllStudentDetails() {
		List<StudentEntity> student = adminSupportService.getAllStudentDetails();
		return new ResponseEntity<>(student, HttpStatus.OK);
	}
	
	@GetMapping("/getAllTrainingDetails")
	public ResponseEntity<List<TrainingEntity>> getAllTrainingDetails() {
		List<TrainingEntity> training = adminSupportService.getAllTrainingDetails();
		return new ResponseEntity<>(training, HttpStatus.OK);
	}
	
	@GetMapping("/getAllExamDetails")
	public ResponseEntity<List<CertificationExamEntity>> getAllExamDetails() {
		List<CertificationExamEntity> exam = adminSupportService.getAllExamDetails();
		return new ResponseEntity<>(exam, HttpStatus.OK);
	}

	@PostMapping("/sendEmail")
	public boolean sendEmail(@RequestBody ReminderDto  reminder)  { 
		return adminSupportService.sendEmail(reminder);
	}
	
	public StudentEntity convertToStudentEntity(StudentDto studentDto) {
		StudentEntity studentEntity = new StudentEntity();
		studentEntity.setStudentFirstName(studentDto.getStudentFirstName());
		studentEntity.setStudentLastName(studentDto.getStudentLastName());
		studentEntity.setStudentEmail(studentDto.getStudentEmail());
		studentEntity.setStudentGender(studentDto.getStudentGender());
		studentEntity.setStudentPhoneNumber(studentDto.getStudentPhoneNumber());
		return studentEntity;
	}

	public StudentDto convertToStudentDto(StudentEntity studentEntity) {
		StudentDto studentDto = new StudentDto();
		studentDto.setStudentFirstName(studentEntity.getStudentFirstName());
		studentDto.setStudentLastName(studentEntity.getStudentLastName());
		studentDto.setStudentEmail(studentEntity.getStudentEmail());
		studentDto.setStudentGender(studentEntity.getStudentGender());
		studentDto.setStudentPhoneNumber(studentEntity.getStudentPhoneNumber());
		return studentDto;
	}

}
