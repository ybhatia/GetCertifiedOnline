package com.cg.gco.adminSupport.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.client.RestTemplate;

import com.cg.gco.adminSupport.configuration.EmailConfig;
import com.cg.gco.adminSupport.controller.AdminSupportController;
import com.cg.gco.adminSupport.dao.CertificationExamDao;
import com.cg.gco.adminSupport.dao.StudentDao;
import com.cg.gco.adminSupport.dao.TrainingDao;
import com.cg.gco.adminSupport.dto.ReminderDto;
import com.cg.gco.adminSupport.entity.CertificationExamEntity;
import com.cg.gco.adminSupport.entity.StudentEntity;
import com.cg.gco.adminSupport.entity.TrainingEntity;
import com.cg.gco.adminSupport.exception.CustomException;
import com.cg.gco.adminSupport.exception.MailNotSentException;
import com.sun.mail.smtp.SMTPAddressFailedException;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

@Service
public class AdminSupportServiceImpl implements AdminSupportService {

	@Autowired
	StudentDao studentDao;

	@Autowired
	TrainingDao trainingDao;

	@Autowired
	CertificationExamDao examDao;

	@Autowired
	EmailConfig emailConfig;

	@Autowired
	private Configuration configuration;

	@Autowired
	private JavaMailSender sender;

	@Autowired
	private RestTemplate restTemplate;

	private static final String URI = "";

	final static Logger logger = LoggerFactory.getLogger(AdminSupportController.class);

//	@Override
//	public StudentEntity getStudentById(Integer studentId) throws CustomException {
//		Optional<StudentEntity> optional = studentDao.findById(studentId);
//		if (optional.isPresent()) {
//			StudentEntity student = optional.get();
//			return student;
//		} else {
//			logger.error("Sorry!!! No such student Id is found");
//			throw new CustomException(String.format("Sorry, Student with Student Id : %d Not Found", studentId));
//		}
//	}

	@Override
	public StudentEntity getStudentById(Integer studentId) throws CustomException {
		Optional<StudentEntity> optional = studentDao.findById(studentId);
		if (optional.isPresent()) {
			StudentEntity student = optional.get();
			return student;
		} else {
			logger.error("Sorry!!! No such student Id is found");
			throw new CustomException(String.format("Sorry, Student with Student Id : %d Not Found", studentId));
		}
	}

	@Override
	public List<TrainingEntity> getTrainingDetailsByStudentId(Integer studentId) throws CustomException {
		List<TrainingEntity> trainingList = trainingDao.searchTrainingDetailsByStudentId(studentId);
		if (trainingList.isEmpty()) {
			logger.error("Sorry!!! No such student Id is found");
			throw new CustomException("Sorry!!! No such student Id is found");
		}
		return trainingList;
	}

	@Override
	public List<CertificationExamEntity> searchExamDetailsByStudentId(Integer studentId) throws CustomException {
		List<CertificationExamEntity> examList = examDao.searchExamDetailsByStudentId(studentId);
		if (examList.isEmpty()) {
			logger.error("Sorry!!! No such student Id is found");
			throw new CustomException("Sorry!!! No such student Id is found");
		}
		return examList;
	}

	@Override
	public boolean sendEmail(ReminderDto reminder) {

		MimeMessage message = sender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Template template = configuration.getTemplate("email-template.ftl");
			Map<String, Object> model = new HashMap<>();
			model.put("message", reminder.getMessage());
			model.put("date", reminder.getExamDate());
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
			helper.setTo(reminder.getEmailId());
			helper.setText(html, true);
			helper.setSubject("Scheduled Exam Reminder for " + reminder.getStudentName());
			helper.setFrom("getcertifiedonlineapp@gmail.com");
			sender.send(message);
		} catch (SMTPAddressFailedException exception) {
			throw new MailNotSentException(exception.getMessage());
		} catch (MailException | MessagingException | IOException | TemplateException exception) {
			throw new MailNotSentException(exception.getMessage());
		}
		return true;
	}

	@Override
	public List<StudentEntity> getAllStudentDetails() {
		List<StudentEntity> studList = new ArrayList<>();
		StudentEntity[] student = null;
		String url = "http://localhost:9092/payment/getAllStudentDetails";
		student = restTemplate.getForObject(url, StudentEntity[].class);
		for (StudentEntity stud : student) {
			studentDao.save(stud);
			studList.add(stud);
		}
		return studentDao.findAll();
	}

	@Override
	public List<TrainingEntity> getAllTrainingDetails() {
		List<TrainingEntity> trainingList = new ArrayList<>();
		TrainingEntity[] training = null;
		String url = "http://localhost:9092/payment/getAllTrainingDetails";
		training = restTemplate.getForObject(url, TrainingEntity[].class);
		for (TrainingEntity trainingVar : training) {
			trainingDao.save(trainingVar);
			trainingList.add(trainingVar);
		}
		return trainingDao.findAll();
	}

	@Override
	public List<CertificationExamEntity> getAllExamDetails() {
		List<CertificationExamEntity> examList = new ArrayList<>();
		CertificationExamEntity[] exam = null;
		String url = "http://localhost:9092/payment/getAllExamDetails";
		exam = restTemplate.getForObject(url, CertificationExamEntity[].class);
		for (CertificationExamEntity examVar : exam) {
			examDao.saveAndFlush(examVar);
			examList.add(examVar);
		}
		return examDao.findAll();
	}

}
