package com.cg.gco.adminSupport.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.gco.adminSupport.entity.StudentEntity;

public interface StudentDao extends JpaRepository<StudentEntity, Integer> {

}
