package com.cg.gco.adminSupport.dto;

public class StudentDto {

	private Integer studentId;
	private String studentFirstName;
	private String studentLastName;
	private String studentGender;
	private String studentEmail;
	private Long studentPhoneNumber;

	public StudentDto() {
		super();
	}

	public StudentDto(Integer studentId, String studentFirstName, String studentLastName, String studentGender,
			String studentEmail, Long studentPhoneNumber) {
		super();
		this.studentId = studentId;
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.studentGender = studentGender;
		this.studentEmail = studentEmail;
		this.studentPhoneNumber = studentPhoneNumber;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Long getStudentPhoneNumber() {
		return studentPhoneNumber;
	}

	public void setStudentPhoneNumber(Long studentPhoneNumber) {
		this.studentPhoneNumber = studentPhoneNumber;
	}

	@Override
	public String toString() {
		return "StudentDto [studentId=" + studentId + ", studentFirstName=" + studentFirstName + ", studentLastName="
				+ studentLastName + ", studentGender=" + studentGender + ", studentEmail=" + studentEmail
				+ ", studentPhoneNumber=" + studentPhoneNumber + "]";
	}

}
