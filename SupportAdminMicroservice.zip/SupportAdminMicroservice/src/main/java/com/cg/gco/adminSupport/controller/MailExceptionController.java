package com.cg.gco.adminSupport.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cg.gco.adminSupport.dto.Response;
import com.cg.gco.adminSupport.exception.MailNotSentException;

@RestControllerAdvice
public class MailExceptionController {
		@ExceptionHandler(MailNotSentException.class)
		public ResponseEntity<Response> handleMailNotSentException(MailNotSentException ex)
		{
			Response response=new Response(HttpStatus.BAD_REQUEST.value(),ex.getMessage());
			
			return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
			
		}

}
