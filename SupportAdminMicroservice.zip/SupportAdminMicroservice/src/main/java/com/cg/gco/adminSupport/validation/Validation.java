package com.cg.gco.adminSupport.validation;

import java.time.LocalDate;
import java.util.regex.Pattern;

public class Validation {

	public boolean isValidId(String id) {
		String idPattern = "^[0-9_-]{2,5}$";
		if (Pattern.matches(idPattern, id))
			return true;
		else
			return false;
	}
	

	public boolean isValidExamDate(String string) {
		String date = string.toString();
		String idPattern = "^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$";
		if (Pattern.matches(idPattern, date))
			return true;
		else
			return false;
	}

}
