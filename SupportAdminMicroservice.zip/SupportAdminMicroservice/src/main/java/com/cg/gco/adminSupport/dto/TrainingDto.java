package com.cg.gco.adminSupport.dto;

import java.time.LocalDate;

public class TrainingDto {

	private Integer trainerId;
	private Integer studentId;
	private Integer courseId;
	private String courseName;
	private String trainerName;
	private Integer trainingDuration;
	private LocalDate trainingStartDate;
	private LocalDate trainingEndDate;

	public TrainingDto() {
		super();
	}

	public TrainingDto(Integer trainerId, Integer studentId, Integer courseId, String courseName, String trainerName,
			Integer trainingDuration, LocalDate trainingStartDate, LocalDate trainingEndDate) {
		super();
		this.trainerId = trainerId;
		this.studentId = studentId;
		this.courseId = courseId;
		this.courseName = courseName;
		this.trainerName = trainerName;
		this.trainingDuration = trainingDuration;
		this.trainingStartDate = trainingStartDate;
		this.trainingEndDate = trainingEndDate;
	}

	public Integer getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(Integer trainerId) {
		this.trainerId = trainerId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public Integer getTrainingDuration() {
		return trainingDuration;
	}

	public void setTrainingDuration(Integer trainingDuration) {
		this.trainingDuration = trainingDuration;
	}

	public LocalDate getTrainingStartDate() {
		return trainingStartDate;
	}

	public void setTrainingStartDate(LocalDate trainingStartDate) {
		this.trainingStartDate = trainingStartDate;
	}

	public LocalDate getTrainingEndDate() {
		return trainingEndDate;
	}

	public void setTrainingEndDate(LocalDate trainingEndDate) {
		this.trainingEndDate = trainingEndDate;
	}

	@Override
	public String toString() {
		return "TrainingDto [trainerId=" + trainerId + ", studentId=" + studentId + ", courseId=" + courseId
				+ ", courseName=" + courseName + ", trainerName=" + trainerName + ", trainingDuration="
				+ trainingDuration + ", trainingStartDate=" + trainingStartDate + ", trainingEndDate=" + trainingEndDate
				+ "]";
	}

}
