package com.cg.gco.adminSupport.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.gco.adminSupport.dto.ReminderDto;
import com.cg.gco.adminSupport.entity.CertificationExamEntity;
import com.cg.gco.adminSupport.entity.StudentEntity;
import com.cg.gco.adminSupport.entity.TrainingEntity;
import com.cg.gco.adminSupport.exception.CustomException;

@Service
public interface AdminSupportService {

	StudentEntity getStudentById(Integer studentId) throws CustomException;

	List<TrainingEntity> getTrainingDetailsByStudentId(Integer studentId) throws CustomException;

	List<CertificationExamEntity> searchExamDetailsByStudentId(Integer studentId) throws CustomException;

	boolean sendEmail(ReminderDto reminder);
	
	List<StudentEntity> getAllStudentDetails();
	
	List<TrainingEntity> getAllTrainingDetails();
	
	List<CertificationExamEntity> getAllExamDetails();
}
