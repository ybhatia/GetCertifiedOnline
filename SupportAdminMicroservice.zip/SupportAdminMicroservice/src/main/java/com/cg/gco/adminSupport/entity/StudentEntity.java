package com.cg.gco.adminSupport.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "studentTable")
public class StudentEntity {

	@Id
	@Column(name = "student_id")
	private Integer studentId;
	@Column(name = "student_first_name")
	private String studentFirstName;
	@Column(name = "student_last_name")
	private String studentLastName;
	@Column(name = "student_gender")
	private String studentGender;
	@Column(name = "student_email")
	private String studentEmail;
	@Column(name = "student_phoneNumber")
	private Long studentPhoneNumber;

	public StudentEntity() {
		super();
	}

	public StudentEntity(Integer studentId, String studentFirstName, String studentLastName, String studentGender,
			String studentEmail, Long studentPhoneNumber) {
		super();
		this.studentId = studentId;
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.studentGender = studentGender;
		this.studentEmail = studentEmail;
		this.studentPhoneNumber = studentPhoneNumber;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Long getStudentPhoneNumber() {
		return studentPhoneNumber;
	}

	public void setStudentPhoneNumber(Long studentPhoneNumber) {
		this.studentPhoneNumber = studentPhoneNumber;
	}

	@Override
	public String toString() {
		return "StudentEntity [studentId=" + studentId + ", studentFirstName=" + studentFirstName + ", studentLastName="
				+ studentLastName + ", studentGender=" + studentGender + ", studentEmail=" + studentEmail
				+ ", studentPhoneNumber=" + studentPhoneNumber + "]";
	}

}
