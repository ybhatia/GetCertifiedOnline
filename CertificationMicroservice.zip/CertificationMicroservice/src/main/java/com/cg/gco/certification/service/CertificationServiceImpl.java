package com.cg.gco.certification.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.platform.commons.util.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gco.certification.dao.CertificationDao;
import com.cg.gco.certification.dao.CourseDao;
import com.cg.gco.certification.dao.TrainerDao;
import com.cg.gco.certification.dto.CertificationDto;
import com.cg.gco.certification.dto.CourseDto;
import com.cg.gco.certification.dto.TrainerDto;
import com.cg.gco.certification.dto.request.AddCertificationRequest;
import com.cg.gco.certification.dto.request.UpdateCertificationRequest;
import com.cg.gco.certification.entity.CertificationEntity;
import com.cg.gco.certification.entity.CourseEntity;
import com.cg.gco.certification.entity.TrainerEntity;
import com.cg.gco.certification.exception.BadRequestException;
import com.cg.gco.certification.exception.NotFoundException;


@Service
public class CertificationServiceImpl implements CertificationService {

	@Autowired
	private CertificationDao certificationDao;

	@Autowired
	private TrainerDao trainerDao;

	@Autowired
	private CourseDao courseDao;
	
	CertificationDto convert(CertificationEntity certification) {
		if (certification != null) {
		CertificationDto certificationDto = new CertificationDto();
		BeanUtils.copyProperties(certification, certificationDto);
		CourseDto courseDto = new CourseDto();
		BeanUtils.copyProperties(certification.getCourse(), courseDto);
		certificationDto.setCourse(courseDto);
		TrainerDto trainerDto = new TrainerDto();
		BeanUtils.copyProperties(certification.getTrainer(), trainerDto);
		certificationDto.setTrainer(trainerDto);
		return certificationDto;
		}
		return null;
	}
	

	@Override
	public void addCertification(AddCertificationRequest addCertificationRequest)
			throws NotFoundException, BadRequestException {
		
		
//		System.out.println(addCertificationRequest.getCertificationName());
//		System.out.println(addCertificationRequest.getCourseId());

		
		
		// validate fields
		if (StringUtils.isBlank(addCertificationRequest.getCertificationName())) {
			throw new BadRequestException("Certification Name cannot be null.");
		} else if (addCertificationRequest.getTrainerId() == null) {
			throw new BadRequestException("TrainerId cannot be null.");
		} else if (addCertificationRequest.getCourseId() == null) {
			throw new BadRequestException("CourseId cannot be null.");
		} else if (addCertificationRequest.getStartDate() == null) {
			throw new BadRequestException("Start Date cannot be null.");
		} else if (addCertificationRequest.getEndDate() == null) {
			throw new BadRequestException("End Date cannot be null.");
		} else if (addCertificationRequest.getEndDate().before(addCertificationRequest.getStartDate())) {
			throw new BadRequestException("Start date cannot be greater than End date");
		}  else if (addCertificationRequest.getEndDate().equals(addCertificationRequest.getStartDate())) {
			throw new BadRequestException("Start date and End date cannot be same.");
		} else if (addCertificationRequest.getStartDate().before(new Date())) {
			throw new BadRequestException("Start date cannot be before Current Date");
		}else if (addCertificationRequest.getCertificationCost() == null) {
			throw new BadRequestException("Certification Cost cannot be null.");
		}

		// Validate Trainer
		Optional<TrainerEntity> trainer = trainerDao.findById(addCertificationRequest.getTrainerId());
		if (!trainer.isPresent()) {
			throw new NotFoundException("Trainer not found");
		}
		if (certificationDao.existsByTrainerIdAndEndDate(addCertificationRequest.getTrainerId(),
				addCertificationRequest.getEndDate())) {
			throw new BadRequestException("Trainer is already assigned.");
		}


		// Validate Course
		Optional<CourseEntity> course = courseDao.findById(addCertificationRequest.getCourseId());
		if (!course.isPresent()) {
			throw new NotFoundException("Course not found");
		}
		if (certificationDao.existsByCourseIdAndStartDate(addCertificationRequest.getCourseId(),
				addCertificationRequest.getStartDate())) {
			throw new BadRequestException("Same course already exists on this date.");
		}

		// Validate Certification
		if (certificationDao.existsByTrainerIdAndCourseIdAndStartDate(addCertificationRequest.getTrainerId(),
				addCertificationRequest.getCourseId(), addCertificationRequest.getStartDate())) {
			throw new BadRequestException("Certification already exists.");
		}
		
		CertificationEntity certification = new CertificationEntity();
		certification.setCertificationName(addCertificationRequest.getCertificationName());
		certification.setTrainer(trainer.get());
		certification.setCourse(course.get());
		certification.setStartDate(addCertificationRequest.getStartDate());
		certification.setEndDate(addCertificationRequest.getEndDate());
		certification.setCertificationCost(addCertificationRequest.getCertificationCost());
		certificationDao.save(certification);
	}

	/*
	 * Get All certificationDto
	 */
	@Override
	public List<CertificationDto> getCertifications() {
		List<CertificationEntity> certificationList = certificationDao.findAll();
		if (!certificationList.isEmpty()) {
			List<CertificationDto> certificationDtoList = new ArrayList<CertificationDto>();
			for (CertificationEntity certification : certificationList) {
				certificationDtoList.add(convert(certification));
			}
			return certificationDtoList;
		}
		return null;
	}
	
	@Override
	public CertificationDto getCertifications(Long certificationId) throws NotFoundException {
		Optional<CertificationEntity> certificationOptional = certificationDao.findById(certificationId);
		if (!certificationOptional.isPresent()) {
			throw new NotFoundException("Certification not found");
		}
		return convert(certificationOptional.get());
	}

	/*
	 * Get All Faculties
	 */
	@Override
	public List<TrainerDto> getFaculties() {
		List<TrainerEntity> trainerList = trainerDao.findAll();
		if (!trainerList.isEmpty()) {
			List<TrainerDto> trainerDtoList = new ArrayList<TrainerDto>();
			for (TrainerEntity trainerEntity : trainerList) {
				TrainerDto trainerDto = new TrainerDto();
				BeanUtils.copyProperties(trainerEntity, trainerDto);
				trainerDtoList.add(trainerDto);
			}
			return trainerDtoList;
		}
		return null;
	}

	/*
	 * Get All Courses
	 */
	@Override
	public List<CourseDto> getCourses() {
		List<CourseEntity> courseList = courseDao.findAll();
		if (!courseList.isEmpty()) {
			List<CourseDto> courseDtoList = new ArrayList<CourseDto>();
			for (CourseEntity courseEntity : courseList) {
				CourseDto courseDto = new CourseDto();
				BeanUtils.copyProperties(courseEntity, courseDto);
				courseDtoList.add(courseDto);
			}
			
			return courseDtoList;
		}
		return null;
	}

	
	/*
	 * Update a Certification
	 */
	@Override
	public void updateCertification(Long certificationId, UpdateCertificationRequest updateCertificationRequest)
			throws NotFoundException, BadRequestException {

		// If nothing was filled
		if (updateCertificationRequest.getStartDate() == null && updateCertificationRequest.getEndDate() == null
				&& updateCertificationRequest.getTrainerId() == null) {
			throw new BadRequestException("Nothing to update. Please fill atleast 1 field.");
		}

		Optional<CertificationEntity> certificationOptional = certificationDao.findById(certificationId);
		if (!certificationOptional.isPresent()) {
			throw new NotFoundException("Certification not found");
		}

		CertificationEntity certification = certificationOptional.get();

		// validate dates
		if (updateCertificationRequest.getStartDate() != null && updateCertificationRequest.getEndDate() != null) {
			if (updateCertificationRequest.getEndDate().before(updateCertificationRequest.getStartDate())) {
				throw new BadRequestException("Start date cannot be greater than End date");
			}
			certification.setStartDate(updateCertificationRequest.getStartDate());
			certification.setEndDate(updateCertificationRequest.getEndDate());

		} else if (updateCertificationRequest.getStartDate() != null) {
			if (certification.getEndDate().before(updateCertificationRequest.getStartDate())) {
				throw new BadRequestException("Start date cannot be greater than End date");
			} else if (updateCertificationRequest.getStartDate().before(new Date())) {
				throw new BadRequestException("Start date cannot be before Current date");
			} else if (updateCertificationRequest.getStartDate().equals(certification.getEndDate())) {
				throw new BadRequestException("Start date and End date cannot be same.");
			}
			certification.setStartDate(updateCertificationRequest.getStartDate());

		} else if (updateCertificationRequest.getEndDate() != null) {
			if (updateCertificationRequest.getEndDate().before(certification.getStartDate())) {
				throw new BadRequestException("Start date cannot be greater than End date");
			} else if (updateCertificationRequest.getEndDate().before(new Date())) {
				throw new BadRequestException("End date cannot be before Current date");
			} else if (updateCertificationRequest.getEndDate().equals(certification.getStartDate())) {
				throw new BadRequestException("Start date and End date cannot be same.");
			}
			certification.setEndDate(updateCertificationRequest.getEndDate());
		}
		// validate trainer id
		if (updateCertificationRequest.getTrainerId() != null) {
			Optional<TrainerEntity> trainer = trainerDao.findById(updateCertificationRequest.getTrainerId());
			if (!trainer.isPresent()) {
				throw new NotFoundException("Trainer not found");
			}
			certification.setTrainer(trainer.get());
		}
		// validate certification cost
		if (updateCertificationRequest.getCertificationCost() != null) {
			certification.setCertificationCost(updateCertificationRequest.getCertificationCost());
		}
		// validate name
		if (StringUtils.isNotBlank(updateCertificationRequest.getCertificationName())) {
			certification.setCertificationName(updateCertificationRequest.getCertificationName());
		}

		certificationDao.save(certification);
	}

	/*
	 * Delete a Training
	 */
	@Override
	public void deleteCertification(Long certificationId) throws NotFoundException {
		if (!certificationDao.existsById(certificationId)) {
			throw new NotFoundException("Certification not found");
		}
		certificationDao.deleteById(certificationId);
	}

}
