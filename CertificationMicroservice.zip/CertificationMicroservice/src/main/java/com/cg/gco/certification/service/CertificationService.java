package com.cg.gco.certification.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.gco.certification.dto.CertificationDto;
import com.cg.gco.certification.dto.CourseDto;
import com.cg.gco.certification.dto.TrainerDto;
import com.cg.gco.certification.dto.request.AddCertificationRequest;
import com.cg.gco.certification.dto.request.UpdateCertificationRequest;
import com.cg.gco.certification.exception.BadRequestException;
import com.cg.gco.certification.exception.NotFoundException;

@Service
public interface CertificationService {
	
	public void addCertification(AddCertificationRequest addCertificationRequest) throws NotFoundException, BadRequestException;

	CertificationDto getCertifications(Long certificationId) throws NotFoundException;

	List<CertificationDto> getCertifications();
	List<TrainerDto> getFaculties();
	List<CourseDto> getCourses();

	void updateCertification(Long certificationId, UpdateCertificationRequest updateCertificationRequest)
			throws NotFoundException, BadRequestException;

	void deleteCertification(Long certificationId) throws NotFoundException;

}
