package com.cg.gco.certification.dto;

import java.util.Date;

public class CertificationDto {
	
	private Long id;
	
	private Date startDate;

	private Date endDate;

	private TrainerDto trainer;

	private CourseDto course;
	
	private Long certificationCost;
	
	private String certificationName;

	
	public CertificationDto() {
	}

	public CertificationDto(Long id, Date startDate, Date endDate, TrainerDto trainer, CourseDto course,
			Long certificationCost,String certificationName) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.trainer = trainer;
		this.course = course;
		this.certificationCost = certificationCost;
		this.certificationName = certificationName;
	}

	@Override
	public String toString() {
		return "CertificationDto [id=" + id + ", startDate=" + startDate + ", endDate=" + endDate + ", trainer="
				+ trainer + ", course=" + course + ", certificationCost=" + certificationCost + ", certificationName="
				+ certificationName + "]";
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public TrainerDto getTrainer() {
		return trainer;
	}

	public void setTrainer(TrainerDto trainer) {
		this.trainer = trainer;
	}

	public CourseDto getCourse() {
		return course;
	}

	public void setCourse(CourseDto course) {
		this.course = course;
	}

	public Long getCertificationCost() {
		return certificationCost;
	}

	public void setCertificationCost(Long certificationCost) {
		this.certificationCost = certificationCost;
	}
	
}
