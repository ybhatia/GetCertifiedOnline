package com.cg.gco.certification.dto;

public class TrainerDto {

	private Long id;
	
	private String trainerName;

	private String trainerSkill;

	public TrainerDto() {
	}

	public TrainerDto(Long id, String trainerName, String trainerSkill) {
		super();
		this.id = id;
		this.trainerName = trainerName;
		this.trainerSkill = trainerSkill;
	}

	@Override
	public String toString() {
		return "TrainerDto [id=" + id + ", trainerName=" + trainerName + ", trainerSkill=" + trainerSkill + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getTrainerSkill() {
		return trainerSkill;
	}

	public void setTrainerSkill(String trainerSkill) {
		this.trainerSkill = trainerSkill;
	}

}
