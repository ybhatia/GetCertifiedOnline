package com.cg.gco.certification.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.gco.certification.entity.CertificationEntity;

public interface CertificationDao extends JpaRepository<CertificationEntity, Long>{

	Boolean existsByTrainerIdAndCourseIdAndStartDate(Long trainerId, Long CourseId, Date startDate);
	
	Boolean existsByCourseIdAndStartDate(Long CourseId, Date startDate);

	Boolean existsByTrainerIdAndEndDate(Long trainerId,Date endDate);

}
