package com.cg.gco.certification.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "courses")
public class CourseEntity extends BaseEntity {

	@Column(name = "course_name")
	private String courseName;
	
	public CourseEntity() {
	}

	public CourseEntity(String courseName, Long id) {
		this.setId(id);
		this.courseName = courseName;
	}


	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

}
