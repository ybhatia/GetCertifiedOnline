package com.cg.gco.certification.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "certification")
public class CertificationEntity extends BaseEntity {
	
	@Column
	private String certificationName;
	
	@Column(name = "start_date", nullable = false)
	private Date startDate;

	@Column(name = "end_date", nullable = false)
	private Date endDate;

	@ManyToOne
	@JoinColumn(name = "trainer_id", nullable = false)
	private TrainerEntity trainer;

	@ManyToOne
	@JoinColumn(name = "course_id", nullable = false)
	private CourseEntity course;
	
	@Column
	private Long certificationCost;
	

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
			
	public TrainerEntity getTrainer() {
		return trainer;
	}

	public void setTrainer(TrainerEntity trainer) {
		this.trainer = trainer;
	}

	public CourseEntity getCourse() {
		return course;
	}

	public void setCourse(CourseEntity course) {
		this.course = course;
	}

	public Long getCertificationCost() {
		return certificationCost;
	}

	public void setCertificationCost(Long certificationCost) {
		this.certificationCost = certificationCost;
	}
	
	
}