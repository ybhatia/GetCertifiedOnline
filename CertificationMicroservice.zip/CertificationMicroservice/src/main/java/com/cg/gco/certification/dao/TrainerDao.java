package com.cg.gco.certification.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.gco.certification.entity.TrainerEntity;

public interface TrainerDao extends JpaRepository<TrainerEntity, Long> {

}
