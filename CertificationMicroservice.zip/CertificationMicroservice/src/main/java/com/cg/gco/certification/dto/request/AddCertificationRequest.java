package com.cg.gco.certification.dto.request;

import java.util.Date;

public class AddCertificationRequest {
	
	private String certificationName;
	
	private Date startDate;

	private Date endDate;

	private Long trainerId;

	private Long courseId;
	
	private Long certificationCost;
	
	public AddCertificationRequest() {
	}

	public AddCertificationRequest(String certificationName, Date startDate, Date endDate, Long trainerId,
			Long courseId,Long certificationCost) {
		super();
		this.certificationName = certificationName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.trainerId = trainerId;
		this.courseId = courseId;
		this.certificationCost = certificationCost;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Long getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(Long trainerId) {
		this.trainerId = trainerId;
	}

	public Long getCourseId() {
		return courseId;
	}

	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}

	public Long getCertificationCost() {
		return certificationCost;
	}

	public void setCertificationCost(Long certificationCost) {
		this.certificationCost = certificationCost;
	}
}
