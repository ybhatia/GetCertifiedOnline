package com.cg.gco.certification.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.gco.certification.dto.CertificationDto;
import com.cg.gco.certification.dto.CourseDto;
import com.cg.gco.certification.dto.TrainerDto;
import com.cg.gco.certification.dto.request.AddCertificationRequest;
import com.cg.gco.certification.dto.request.UpdateCertificationRequest;
import com.cg.gco.certification.dto.response.SuccessResponse;
import com.cg.gco.certification.exception.BadRequestException;
import com.cg.gco.certification.exception.NotFoundException;
import com.cg.gco.certification.service.CertificationService;

@RestController
@RequestMapping("/certification")
@CrossOrigin("http://localhost:4200")
public class CertificationController {
	@Autowired
	CertificationService certificationService;

	@PostMapping("/addcertification")
	public SuccessResponse addCertification(@RequestBody AddCertificationRequest addCertificationRequest)
			throws BadRequestException, NotFoundException {
		certificationService.addCertification(addCertificationRequest);
		return new SuccessResponse(true,"Successfully added new certification");
	}
	
	/*x
	 * End Point to get a certification.
	 */
	@GetMapping("/getbyid/{certificationId}")
	public CertificationDto getoertification(@PathVariable Long certificationId) throws NotFoundException {
		return certificationService.getCertifications(certificationId);
	} 
	

	/*
	 * End Point to get all the certifications.
	 */
	@GetMapping("/certifications")
	public List<CertificationDto> getCertifications() {
		System.out.println(certificationService.getCertifications().toString());
		return certificationService.getCertifications();
	}
	
	/*
	 * End Point to get all the faculties.
	 */
	@GetMapping("/trainers")
	public List<TrainerDto> getFaculties() {
		System.out.println(certificationService.getFaculties().toString());
		return certificationService.getFaculties();
	}

	
	/*
	 * End Point to get all the courses.
	 */
	@GetMapping("/courses")
	public List<CourseDto> getCourses() {
		List<CourseDto> check=certificationService.getCourses();
		System.out.println(check.toString());
		return check;
	}


	/*
	 * End Point to update a certification.
	 */
	@PutMapping("/update/{certificationId}")
	public SuccessResponse updateCertification(@PathVariable Long certificationId,
			@RequestBody UpdateCertificationRequest updateCertificationRequest) throws BadRequestException, NotFoundException {
		
		certificationService.updateCertification(certificationId, updateCertificationRequest);
		return new SuccessResponse(true);
	}

	/*
	 * End Point to delete a certification.
	 */
	@DeleteMapping("/delete/{certificationId}")
	public SuccessResponse deleteCertification(@PathVariable Long certificationId) throws NotFoundException, BadRequestException {
		certificationService.deleteCertification(certificationId);
		return new SuccessResponse(true);
	}
}
