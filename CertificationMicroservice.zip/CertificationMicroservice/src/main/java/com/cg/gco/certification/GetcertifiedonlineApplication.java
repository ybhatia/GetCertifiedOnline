package com.cg.gco.certification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.cg.gco.certification.controller.CertificationController;

@SpringBootApplication
public class GetcertifiedonlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetcertifiedonlineApplication.class, args);
	}

}
