package com.cg.gco.certification;

import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.gco.certification.dao.CertificationDao;
import com.cg.gco.certification.dao.CourseDao;
import com.cg.gco.certification.dao.TrainerDao;
import com.cg.gco.certification.exception.NotFoundException;
import com.cg.gco.certification.service.CertificationService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GetcertifiedonlineApplicationTests {

	@MockBean
	private CertificationDao trainingRepository;

	@MockBean
	private CourseDao courseRepository;

	@MockBean
	private TrainerDao facultyRepository;

	@Autowired
	private CertificationService service;
	
	@Test
	public void deleteTrainingTest() throws NotFoundException {
		service.deleteCertification(200L);
		verify(trainingRepository).existsById(200L);
	}

}
