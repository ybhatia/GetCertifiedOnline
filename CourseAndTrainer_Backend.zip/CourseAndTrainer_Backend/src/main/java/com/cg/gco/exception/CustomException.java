package com.cg.gco.exception;

public class CustomException extends RuntimeException {
    public CustomException(String msg) {
        super(msg);
    }
}
