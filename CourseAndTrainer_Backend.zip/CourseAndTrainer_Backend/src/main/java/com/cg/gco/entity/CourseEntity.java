package com.cg.gco.entity;

import javax.persistence.*;
import java.util.List;

@Entity

@Table(name="courses")
public class CourseEntity {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "course_name")
    private String courseName;

    public CourseEntity() {
        super();
    }
    
    

	public CourseEntity(int id, String courseName) {
		super();
		this.id = id;
		this.courseName = courseName;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	@Override
	public String toString() {
		return "CourseEntity [id=" + id + ", courseName=" + courseName + "]";
	}



}
