package com.cg.gco.services;

import com.cg.gco.dao.CourseDao;
import com.cg.gco.entity.CourseEntity;
import com.cg.gco.exception.CustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    CourseDao courseDao;

    final static Logger logger = LoggerFactory.getLogger(CourseServiceImpl.class);

    @Override
    public CourseEntity addCourse(CourseEntity course) throws CustomException {
        String courseName = course.getCourseName();
        if(courseName == null){
            logger.error("Course Name cannot be null");
            throw new CustomException("Course Name cannot be null");
        }
        List<CourseEntity> courseDetails =(List<CourseEntity>) courseDao.findAll();
        for (int i = 0; i < courseDetails.size(); i++) {
            if (courseDetails.get(i).getCourseName().equals(courseName)) {
                logger.error("Course already exist");
                throw new CustomException(String.format("Course with Course Name: %s already exist", courseName));
            }
        }
        return courseDao.save(course);
    }

    @Override
    public boolean deleteCourse(Integer courseId) throws CustomException {
        Optional<CourseEntity> optional = courseDao.findById(courseId);
        if (optional.isPresent()) {
            courseDao.deleteById(courseId);
            return true;
        } else {
            logger.error("COURSE NOT FOUND ");
            throw new CustomException(String.format("Sorry, Course with Course Id : %d Not Found", courseId));
        }
    }

    @Override
    public CourseEntity updateCourse(CourseEntity course) throws CustomException {
        if(course == null){
            throw new CustomException("Course can not be null");
        }
        return courseDao.save(course);
    }

    @Override
    public List<CourseEntity> getAllCourse(){
        return courseDao.findAll();
    }
}
