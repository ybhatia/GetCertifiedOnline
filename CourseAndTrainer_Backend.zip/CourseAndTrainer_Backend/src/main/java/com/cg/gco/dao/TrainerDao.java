package com.cg.gco.dao;

import com.cg.gco.entity.TrainerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainerDao extends JpaRepository<TrainerEntity, Integer> {
}
