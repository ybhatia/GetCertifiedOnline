package com.cg.gco.dto;


public class CourseDto {

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;
    private String courseName;

    public CourseDto(){ super(); }

    public CourseDto(Integer id, String courseName) {
        super();
        this.id = id;
        this.courseName = courseName;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

	@Override
	public String toString() {
		return "CourseDto [id=" + id + ", courseName=" + courseName + "]";
	}
  
}
