package com.cg.gco.controller;
import com.cg.gco.dto.TrainerDto;
import com.cg.gco.entity.TrainerEntity;
import com.cg.gco.services.TrainerService;
import com.cg.gco.services.TrainerServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/trainer")
@CrossOrigin("*")
public class TrainerController {

    @Autowired
    private TrainerService trainerService;
    final static Logger logger = LoggerFactory.getLogger(TrainerController.class);

    @Autowired
    RestTemplate restTemplate;

    @PostMapping("/addtrainer")
    public ResponseEntity<TrainerDto> addNewTrainer(@RequestBody TrainerDto trainer) {
        TrainerEntity trainerEntity = convertToTrainerEntity(trainer);
        trainerEntity.setTrainerName(trainer.getTrainerName());
        trainerEntity.setTrainerSkill(trainer.getTrainerSkill());
        trainerService.addTrainer(trainerEntity);
        TrainerDto trainerDto = convertToTrainerDto(trainerEntity);
        logger.info("A NEW TRAINER ADDED SUCCESSFULY");
        return new ResponseEntity<>(trainerDto, HttpStatus.OK);

    }

    @GetMapping("/alltrainers")
    public ResponseEntity<List<TrainerEntity>> getAllTrainer() {
        List<TrainerEntity> trainer = trainerService.getAllTrainers();
        return new ResponseEntity<>(trainer, HttpStatus.OK);
    }

    @PutMapping("/update")
    public ResponseEntity<TrainerDto> updateTrainer(@RequestBody TrainerDto trainer) {
        TrainerEntity trainerEntity = convertToTrainerEntity(trainer);
        trainerEntity = trainerService.updateTrainer(trainerEntity);
        TrainerDto trainerDto = convertToTrainerDto(trainerEntity);
        logger.info("TRAINER IS UPDATED SUCCESSFULLY");
        return new ResponseEntity<>(trainerDto, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{trainerId}")
    public boolean deleteTrainer(@PathVariable Integer trainerId) {
        boolean flag = trainerService.deleteTrainer(trainerId);
        logger.info("TRAINER IS REMOVED SUCCESSFULLY");
        return flag;
    }


    public TrainerEntity convertToTrainerEntity(TrainerDto trainerDto) {
        TrainerEntity trainerEntity = new TrainerEntity();
        //trainerEntity.setTrainerId(trainerDto.getTrainerId());
        trainerEntity.setTrainerName(trainerDto.getTrainerName());
        trainerEntity.setTrainerSkill(trainerDto.getTrainerSkill());
        return trainerEntity;
    }

    public TrainerDto convertToTrainerDto(TrainerEntity trainerEntity) {
        TrainerDto trainerDto = new TrainerDto();
        //trainerDto.setTrainerId(trainerEntity.getTrainerId());
        trainerDto.setTrainerName(trainerEntity.getTrainerName());
        trainerDto.setTrainerSkill(trainerEntity.getTrainerSkill());
        return trainerDto;
    }
//    @Autowired
//    TrainerServiceImpl trainerServiceimpl;
//    @PostMapping()
//    public ResponseEntity<TrainerEntity> createMenu(@RequestBody TrainerEntity trainer) {
//
//        return new ResponseEntity<>(trainerServiceimpl.addTrainer(trainer), HttpStatus.OK);

    }

