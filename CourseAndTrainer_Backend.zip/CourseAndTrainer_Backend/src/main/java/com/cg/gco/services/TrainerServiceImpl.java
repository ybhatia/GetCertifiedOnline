package com.cg.gco.services;

import com.cg.gco.dao.TrainerDao;
import com.cg.gco.entity.CourseEntity;
import com.cg.gco.entity.TrainerEntity;
import com.cg.gco.exception.CustomException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainerServiceImpl implements TrainerService{

    @Autowired
    TrainerDao trainerDao;

    final static Logger logger = LoggerFactory.getLogger(TrainerServiceImpl.class);

    @Override
    public TrainerEntity addTrainer(TrainerEntity trainer) throws CustomException {
        String trainerName = trainer.getTrainerName();
        if(trainerName == null){
            logger.error("Trainer Name cannot be null");
            throw new CustomException("Trainer Name cannot be null");
        }
        List<TrainerEntity> trainerDetails =(List<TrainerEntity>) trainerDao.findAll();
        for (int i = 0; i < trainerDetails.size(); i++) {
            if (trainerDetails.get(i).getTrainerName().equals(trainerName)) {
                logger.error("Trainer already exist");
                throw new CustomException(String.format("Trainer with Trainer Name: %s already exist", trainerName));
            }
        }
        return trainerDao.save(trainer);
    }

    @Override
    public boolean deleteTrainer(Integer trainerId) throws CustomException {
        Optional<TrainerEntity> optional = trainerDao.findById(trainerId);
        if (optional.isPresent()) {
            trainerDao.deleteById(trainerId);
            return true;
        } else {
            logger.error("TRAINER NOT FOUND ");
            throw new CustomException(String.format("Sorry, Trainer with Trainer Id : %d Not Found", trainerId));
        }
    }

    @Override
    public TrainerEntity updateTrainer(TrainerEntity trainer) throws CustomException {
        if(trainer == null){
            throw new CustomException("Trainer can not be null");
        }
        return trainerDao
                .save(trainer);
    }

    @Override
    public List<TrainerEntity> getAllTrainers(){
        return trainerDao.findAll();
    }
}
