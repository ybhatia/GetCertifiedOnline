package com.cg.gco.dto;

public class TrainerDto {

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    private Integer id;
    private String trainerName;
    private String trainerSkill;

    public TrainerDto(){ super(); }

    public TrainerDto(Integer id, String trainerName, String trainerSkill) {
        super();
        this.id = id;
        this.trainerName = trainerName;
        this.trainerSkill = trainerSkill;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public void setTrainerName(String trainerName) {
        this.trainerName = trainerName;
    }

    public String getTrainerSkill() {
        return trainerSkill;
    }

    public void setTrainerSkill(String trainerSkill) {
        this.trainerSkill = trainerSkill;
    }

    @Override
    public String toString() {
        return "TrainerEntity [trainerId=" + id + ", trainerName=" + trainerName + ", trainerSkill=" + trainerSkill
                + "]";
    }
}
