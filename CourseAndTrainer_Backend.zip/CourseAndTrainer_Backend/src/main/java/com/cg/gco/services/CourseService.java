package com.cg.gco.services;

import com.cg.gco.entity.CourseEntity;
import com.cg.gco.exception.CustomException;

import java.util.List;

public interface CourseService {

    CourseEntity addCourse(CourseEntity course) throws CustomException;

    boolean deleteCourse(Integer courseId) throws CustomException;

    CourseEntity updateCourse(CourseEntity course);

    List<CourseEntity> getAllCourse();
}
