package com.cg.gco.controller;

import com.cg.gco.dto.CourseDto;
import com.cg.gco.entity.CourseEntity;
import com.cg.gco.exception.CustomException;
import com.cg.gco.services.CourseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/course")
@CrossOrigin("*")
public class CourseController {
    @Autowired
    private CourseService courseService;
        final static Logger logger = LoggerFactory.getLogger(CourseController.class);

    @Autowired
    RestTemplate restTemplate;

    @PostMapping("/addcourse")
    public ResponseEntity<CourseDto> addNewCourse(@RequestBody CourseDto course) {
        CourseEntity courseEntity = convertToCourseEntity(course);
        courseEntity.setCourseName(course.getCourseName());
        courseService.addCourse(courseEntity);
        CourseDto courseDto = convertToCourseDto(courseEntity);
        logger.info("A NEW COURSE ADDED SUCCESSFULY");
        return new ResponseEntity<>(courseDto, HttpStatus.OK);

    }

    @GetMapping("/allcourses")
    public ResponseEntity<List<CourseEntity>> getAllCourses() {
        List<CourseEntity> course = courseService.getAllCourse();
        return new ResponseEntity<>(course, HttpStatus.OK);
    }

    @PutMapping("/update")
    public ResponseEntity<CourseDto> updateCourse(@RequestBody CourseDto course) {
        CourseEntity courseEntity = convertToCourseEntity(course);
        courseEntity = courseService.updateCourse(courseEntity);
        CourseDto courseDto = convertToCourseDto(courseEntity);
        logger.info("COURSE IS UPDATED SUCCESSFULLY");
        return new ResponseEntity<>(courseDto, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public boolean deleteCourse(@PathVariable Integer id) {
        boolean flag = courseService.deleteCourse(id);
        logger.info("COURSE IS REMOVED SUCCESSFULLY");
        return flag;
    }


    /*
     * Handle Course not found Exception
     *
     * @param ex
     */
    @ExceptionHandler(CustomException.class)
    public ResponseEntity<String> handleCourseNotFound(CustomException ex) {
        logger.error("COURSE NOT FOUND!!!", ex);
        String msg = ex.getMessage();
        return new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
    }

    /*
     * Blanket Exception Handler
     *
     * @param ex
     */
    @ExceptionHandler(Throwable.class)
    public ResponseEntity<String> handleAll(Throwable ex) {
        logger.error("Something went wrong", ex);
        String msg = ex.getMessage();
        return new ResponseEntity<>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public CourseEntity convertToCourseEntity(CourseDto courseDto) {
        CourseEntity courseEntity = new CourseEntity();
        courseEntity.setCourseName(courseDto.getCourseName());
        return courseEntity;
    }

    public CourseDto convertToCourseDto(CourseEntity courseEntity) {
        CourseDto courseDto = new CourseDto();
        courseDto.setCourseName(courseEntity.getCourseName());
        return courseDto;
    }
}
