package com.cg.gco.entity;

import javax.persistence.*;

@Entity
@Table(name = "trainers")
public class TrainerEntity {

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	public String trainerName;
	public String trainerSkill;

	public TrainerEntity() {
		super();
	}

	public TrainerEntity(String trainerName, String trainerSkill, Integer id) {
		super();
		this.trainerName = trainerName;
		this.trainerSkill = trainerSkill;
		this.id = id;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getTrainerSkill() {
		return trainerSkill;
	}

	public void setTrainerSkill(String trainerSkill) {
		this.trainerSkill = trainerSkill;
	}

	@Override
	public String toString() {
		return "Trainer [TrainerId =" + id + "TrainerName =" + trainerName + ",TrainerSkill =" + trainerSkill + "]";
	}
}
