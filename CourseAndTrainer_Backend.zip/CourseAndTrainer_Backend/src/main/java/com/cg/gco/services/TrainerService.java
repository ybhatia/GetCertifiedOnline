package com.cg.gco.services;

import com.cg.gco.entity.CourseEntity;
import com.cg.gco.entity.TrainerEntity;
import com.cg.gco.exception.CustomException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TrainerService {

TrainerEntity addTrainer(TrainerEntity trainer);

    boolean deleteTrainer(Integer trainerId) throws CustomException;

    TrainerEntity updateTrainer(TrainerEntity trainer);

    List<TrainerEntity> getAllTrainers();
}
