package com.cg.getcertified;



import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.getcertified.validation.Validation;

@SpringBootTest
public class PaymentTest {
		
	    @Autowired
		Validation validation;

		@Test
		public void testCustomerCvvwithSpecialChar() 
		{
			boolean flag=validation.checkCvv("18#%08");
			assertFalse(flag);	
		}
		@Test
		public void testCustomerCvvWithAlphabets() 
		{
			boolean flag=validation.checkCvv("Avi");
			assertFalse(flag);	
		}  
		@Test
		public void testCustomerCardNumberWithAlphabets() 
		{
			boolean flag=validation.checkCardNumber("Bhavani");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerCardNumberWithNumberAndSpecialChar() 
		{
			boolean flag=validation.checkCardNumber("1234@");
			assertFalse(flag);	
		}
		
		
		@Test
		public void testIsValidIdContainsOnlyDigits() 
		{
			boolean flag=validation.checkId("123455");
			assertTrue(flag);	
		}
		@Test
		public void testIsValidIdWithOnlyAlphabets() 
		{
			boolean flag=validation.checkId("Bhavani");
			assertFalse(flag);	
		}
		
		@Test
		public void testIsValidIdContainsOnlySpecialCharactersAndNumbers() 
		{
			boolean flag=validation.checkId("abcde");
			assertFalse(flag);	
		}
		
		


	}
