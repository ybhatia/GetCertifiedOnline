package com.cg.getcertified;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetCertifiedApplicationTests {

	@Test
	void contextLoads() {
	}

}
