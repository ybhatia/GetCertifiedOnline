package com.cg.getcertified.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.getcertified.entity.TrainingEntity;


public interface TrainingDao extends JpaRepository<TrainingEntity, Integer> {

	@Query(value = "Select * from training where student_id = ?", nativeQuery = true)
	List<TrainingEntity> searchTrainingDetailsByStudentId(Integer studentId);

}
