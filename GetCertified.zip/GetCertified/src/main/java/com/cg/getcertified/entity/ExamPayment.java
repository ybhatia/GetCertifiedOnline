package com.cg.getcertified.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ExamPayment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false)
	private String regCourse;

	@Column(nullable = false)
	private int paymentAmount;

	@Column(nullable = false)
	private long cardNumber;

	@Column(nullable = false)
	private int exipryMonth;

	@Column(nullable = false)
	private int expiryYear;

	public ExamPayment() {

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRegCourse() {
		return regCourse;
	}

	public void setRegCourse(String regCourse) {
		this.regCourse = regCourse;
	}

	public int getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(int paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public int getExipryMonth() {
		return exipryMonth;
	}

	public void setExipryMonth(int exipryMonth) {
		this.exipryMonth = exipryMonth;
	}

	public int getExpiryYear() {
		return expiryYear;
	}

	public void setExpiryYear(int expiryYear) {
		this.expiryYear = expiryYear;
	}




}
