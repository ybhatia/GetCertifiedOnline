package com.cg.getcertified.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.getcertified.entity.CertificationExamEntity;


public interface CertificationExamDao extends JpaRepository<CertificationExamEntity, Integer> {

	@Query(value = "Select * from exam where student_id = ?", nativeQuery = true)
	List<CertificationExamEntity> searchExamDetailsByStudentId(Integer StudentId);

	@Query(value = "Select * from exam where exam_date = ?", nativeQuery = true)
	CertificationExamEntity searchExamDetailsByExamDate(LocalDate examDate);

}
