package com.cg.getcertified.validation;

import org.springframework.stereotype.Repository;

@Repository
public class Validation {
	
	public boolean checkId(String id)
	{
	String regex = "[1-9][0-9]*|0";
	return id.matches(regex);
	}
	
	public boolean checkCardNumber(String cardNumber)
	{
		String regex="((?:(?:\\d{4}[- ]){3}\\d{4}|\\d{16}))(?![\\d])";
		return cardNumber.matches(regex);
	}
	
	
	public boolean checkCvv(String cvv)
	{

		String regex="^[0-9]{3, 4}$";
		return cvv.matches(regex);
	}
	
	public boolean checkExpiryMonth(String expiryMonth)
	{
		String regex="(0?[1-9]|1[012])";
		return expiryMonth.matches(regex);
	}
	
	
	
	public boolean checkExpiryYear(String expiryYear)
	{
		String regex="^[12][0-9]{3}$";
		return expiryYear.matches(regex);
	}

}
