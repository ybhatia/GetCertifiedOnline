package com.cg.getcertified.response;

import com.cg.getcertified.entity.StudentEntity;
import com.cg.getcertified.entity.TrainingPayment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
//@JsonInclude()
public class PaymentResponse {
	
	private boolean error;
	private String message;

	private TrainingPayment trainingPayment;
	
	private StudentEntity student;

	public PaymentResponse() {
		
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public TrainingPayment getTrainingPayment() {
		return trainingPayment;
	}

	public void setTrainingPayment(TrainingPayment trainingPayment) {
		this.trainingPayment = trainingPayment;
	}

	public StudentEntity getStudent() {
		return student;
	}

	public void setStudent(StudentEntity student) {
		this.student = student;
	}
	
	
}
