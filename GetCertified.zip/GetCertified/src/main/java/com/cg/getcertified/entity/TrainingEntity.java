package com.cg.getcertified.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "trainings")
public class TrainingEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(columnDefinition = "serial", name = "trainer_id")
	private Integer trainerId;
	@Column(name = "student_id")
	private Integer studentId;
	@Column(name = "course_id")
	private Integer courseId;
	@Column(name = "course_name")
	private String courseName;
	@Column(name = "trainer_name")
	private String trainerName;
	@Column(name = "training_duration")
	private Integer trainingDuration;
	@Column(name = "training_start_date")
	private LocalDate trainingStartDate;
	@Column(name = "training_end_date")
	private LocalDate trainingEndDate;

	public TrainingEntity() {
		super();
	}

	public TrainingEntity(Integer trainerId, Integer studentId, Integer courseId, String courseName, String trainerName,
			Integer trainingDuration, LocalDate trainingStartDate, LocalDate trainingEndDate) {
		super();
		this.trainerId = trainerId;
		this.studentId = studentId;
		this.courseId = courseId;
		this.courseName = courseName;
		this.trainerName = trainerName;
		this.trainingDuration = trainingDuration;
		this.trainingStartDate = trainingStartDate;
		this.trainingEndDate = trainingEndDate;
	}

	public Integer getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(Integer trainerId) {
		this.trainerId = trainerId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public Integer getTrainingDuration() {
		return trainingDuration;
	}

	public void setTrainingDuration(Integer trainingDuration) {
		this.trainingDuration = trainingDuration;
	}

	public LocalDate getTrainingStartDate() {
		return trainingStartDate;
	}

	public void setTrainingStartDate(LocalDate trainingStartDate) {
		this.trainingStartDate = trainingStartDate;
	}

	public LocalDate getTrainingEndDate() {
		return trainingEndDate;
	}

	public void setTrainingEndDate(LocalDate trainingEndDate) {
		this.trainingEndDate = trainingEndDate;
	}

	@Override
	public String toString() {
		return "TrainingEntity [trainerId=" + trainerId + ", studentId=" + studentId + ", courseId=" + courseId
				+ ", courseName=" + courseName + ", trainerName=" + trainerName + ", trainingDuration="
				+ trainingDuration + ", trainingStartDate=" + trainingStartDate + ", trainingEndDate=" + trainingEndDate
				+ "]";
	}

}
