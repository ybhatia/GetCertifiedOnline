package com.cg.getcertified.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.getcertified.entity.CertificationExamEntity;
import com.cg.getcertified.entity.ExamPayment;
import com.cg.getcertified.entity.StudentEntity;
import com.cg.getcertified.entity.TrainingEntity;
import com.cg.getcertified.entity.TrainingPayment;
import com.cg.getcertified.repository.CertificationExamDao;
import com.cg.getcertified.repository.ExamPaymentRepo;
import com.cg.getcertified.repository.PaymentRepo;
import com.cg.getcertified.repository.StudentDao;
import com.cg.getcertified.repository.TrainingDao;

@Service
public class PaymentService {

	@Autowired
	PaymentRepo paymentRepo;

	@Autowired
	ExamPaymentRepo examPaymentRepo;
	
	@Autowired
	StudentDao studentDao;

	@Autowired
	TrainingDao trainingDao;

	@Autowired
	CertificationExamDao examDao;

	public TrainingPayment addPaymentData(TrainingPayment payeeData) {
		return paymentRepo.save(payeeData);
	}

	public List<TrainingPayment> getPaymentData() {
		List<TrainingPayment> list = new ArrayList<TrainingPayment>();
		paymentRepo.findAll().forEach(list::add);
		return list;
	}
	
	public StudentEntity getStudentById(Integer studentId){
		Optional<StudentEntity> optional = studentDao.findById(studentId);
		if (optional.isPresent()) {
			StudentEntity student = optional.get();
			return student;
		}
		return null; 
	}

	public ExamPayment examPaymentAdd(ExamPayment payment) {
		return examPaymentRepo.save(payment);
	}

	public List<ExamPayment> getExamPayment() {
		List<ExamPayment> list = new ArrayList<ExamPayment>();
		examPaymentRepo.findAll().forEach(list::add);
		return list;

	}
	
	public List<StudentEntity> getAllStudentDetails() {
		return studentDao.findAll();
	}
	
	public List<TrainingEntity> getAllTrainingDetails() {
		return trainingDao.findAll();
	}

	public List<CertificationExamEntity> getAllExamDetails() {
		return examDao.findAll();
	}


}
