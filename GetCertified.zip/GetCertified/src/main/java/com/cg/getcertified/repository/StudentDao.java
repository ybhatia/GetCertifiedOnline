package com.cg.getcertified.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.getcertified.entity.StudentEntity;


public interface StudentDao extends JpaRepository<StudentEntity, Integer> {

}
