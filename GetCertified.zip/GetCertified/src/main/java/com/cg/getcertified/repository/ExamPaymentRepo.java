package com.cg.getcertified.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.getcertified.entity.ExamPayment;

public interface ExamPaymentRepo extends CrudRepository<ExamPayment, Long>{

	
}
