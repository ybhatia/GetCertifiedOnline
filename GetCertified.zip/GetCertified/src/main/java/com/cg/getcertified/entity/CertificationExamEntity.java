package com.cg.getcertified.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "exams")
public class CertificationExamEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(columnDefinition = "serial", name = "exam_id")
	private Integer examId;
	@Column(name = "student_id")
	private Integer studentId;
	@Column(name = "exam_date")
	private LocalDate examDate;
	@Column(name = "exam_start_time")
	private LocalTime examStartTime;
	@Column(name = "exam_end_time")
	private LocalTime examEndTime;
	@Column(name = "exam_duration")
	private Integer examDuration;
	@Column(name = "exam_slot")
	private String examSlot;

	public CertificationExamEntity() {
		super();
	}

	public CertificationExamEntity(Integer examId, Integer studentId, LocalDate examDate, LocalTime examStartTime,
			LocalTime examEndTime, Integer examDuration, String examSlot) {
		super();
		this.examId = examId;
		this.studentId = studentId;
		this.examDate = examDate;
		this.examStartTime = examStartTime;
		this.examEndTime = examEndTime;
		this.examDuration = examDuration;
		this.examSlot = examSlot;
	}

	public Integer getExamId() {
		return examId;
	}

	public void setExamId(Integer examId) {
		this.examId = examId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public LocalTime getExamStartTime() {
		return examStartTime;
	}

	public void setExamStartTime(LocalTime examStartTime) {
		this.examStartTime = examStartTime;
	}

	public LocalTime getExamEndTime() {
		return examEndTime;
	}

	public void setExamEndTime(LocalTime examEndTime) {
		this.examEndTime = examEndTime;
	}

	public Integer getExamDuration() {
		return examDuration;
	}

	public void setExamDuration(Integer examDuration) {
		this.examDuration = examDuration;
	}

	public String getExamSlot() {
		return examSlot;
	}

	public void setExamSlot(String examSlot) {
		this.examSlot = examSlot;
	}

	@Override
	public String toString() {
		return "CertificationExamEntity [examId=" + examId + ", studentId=" + studentId + ", examDate=" + examDate
				+ ", examStartTime=" + examStartTime + ", examEndTime=" + examEndTime + ", examDuration=" + examDuration
				+ ", examSlot=" + examSlot + "]";
	}

}
