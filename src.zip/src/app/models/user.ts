export class User {
    
    userName:string;
    email: string;
    password: string;
    name:string;
    phoneNumber: number;


    constructor(userName,phoneNumber, email, name,password ) {
        this.userName = userName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.name = name;
		this.password = password;
		
		
		
	}

}