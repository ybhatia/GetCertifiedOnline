import { Trainer } from 'src/app/models/trainer';
import { Course } from 'src/app/models/course';

export class Feedback{

        public commSkill : number;
        public doubtClarity : number;
        public timeMgmt : number;
        public studyMaterial : number;
        public comment : string;
        public course: Course;
        public trainer: Trainer;

    // constructor(commSkill, doubtClarity, timeMgmt, studyMaterial, comments, courseId, trainerId){
    //     this.commSkill= commSkill,
    //     this.doubtClarity= doubtClarity,
    //     this.timeMgmt= timeMgmt,
    //     this.studyMaterial= studyMaterial,
    //     this.comments= comments,
    //     this.courseId= courseId,
    //     this.trainerId= trainerId
    // }


}



