export class Student {
    id: any;
    studentId : any;
    studentFirstName : any;
    studentLastName: any;
    studentGender: any;
    studentEmail: any;
    studentPhoneNumber: any;
    constructor(studentId, studentFirstName, studentLastName, studentGender, studentPhoneNumber, studentEmail) {
        this.studentId = studentId;
        this.studentFirstName = studentFirstName;
        this.studentLastName = studentLastName;
        this.studentGender = studentGender;
        this.studentPhoneNumber = studentPhoneNumber;
        this.studentEmail = studentEmail;
    }
}