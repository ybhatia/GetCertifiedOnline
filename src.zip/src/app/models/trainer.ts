import { logging } from 'protractor';

export class Trainer {

    public id : number;
    public trainerName : string;
    public trainerSkill : string;

}
