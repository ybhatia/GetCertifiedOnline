export class Training {
    trainerId: any;
    studentId: any;
    courseId: any;
    courseName: any;
    trainerName: any;
    trainingDuration: any;
    trainingStartDate: any;
    trainingEndDate: any;
    constructor(trainerId, studentId, courseId, courseName, trainerName, trainingDuration, trainingStartDate, trainingEndDate) {
        this.trainerId = trainerId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.courseName = courseName;
        this.trainerName = trainerName;
        this.trainingDuration = trainingDuration;
        this.trainingStartDate = trainingStartDate;
        this.trainingEndDate = trainingEndDate;
    }
}