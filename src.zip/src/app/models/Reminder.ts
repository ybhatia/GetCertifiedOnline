export class Reminder{
    studentName : any;
    emailId : any;
    message : any;
    examDate : any;

    constructor(studentName , emailId, message , examDate){
        this.studentName = studentName;
        this.emailId = emailId;
        this.message = message;
        this.examDate = examDate;
    }
}