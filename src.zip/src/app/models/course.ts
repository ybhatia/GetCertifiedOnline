export class Course {

    public id : number;
    public courseName : string;
}
