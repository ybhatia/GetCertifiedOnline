export class CertificationExam {
    id: any;
    examId : any;
    studentId :any
    examDate : any
    examStartTime : any
    examEndTime : any
    examDuration : any
    examSlot : any;
    constructor(studentId, examId, examDate, examStartTime, examEndTime, examDuration, examSlot) {
        this.studentId = studentId;
        this.examId = examId;
        this.examDate = examDate;
        this.examStartTime = examStartTime;
        this.examEndTime = examEndTime;
        this.examDuration = examDuration;
        this.examSlot = examSlot;
    }
}