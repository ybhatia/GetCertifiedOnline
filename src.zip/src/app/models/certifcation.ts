import { Course } from './course';
import { Trainer } from './trainer';

export class Certification {
    public id:number;
    public certificationName: string;
    public startDate : Date;
    public endDate : Date;
    public trainer : Trainer;
    public course : Course;
    public certificationCost: number;

    // construtor(certificationName,startDate,endDate,trainer,course,certificationCost){
    //     this.certificationName=certificationName;
    //     this.course=course;
    //     this.trainer=trainer;
    //     this.startDate=startDate;
    //     this.endDate=endDate;
    //     this.certificationCost=certificationCost;
    // }
}
