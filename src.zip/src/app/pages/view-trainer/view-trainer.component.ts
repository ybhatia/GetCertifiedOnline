import { Trainer } from 'src/app/models/trainer';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TrainerService } from 'src/app/services/trainer.service';


@Component({
  selector: 'app-view-trainer',
  templateUrl: './view-trainer.component.html',
  styleUrls: ['./view-trainer.component.css']
})
export class ViewTrainerComponent implements OnInit {

  displayedColumns = ['id', 'trainerName','trainerSkill','actions'];
  model: Trainer;
 trainers: Trainer[];
  dataSource : Trainer[];
  errorMessage: any;
  

  constructor(private router: Router, private service : TrainerService) {
    this.model = new Trainer;
  }

  ngOnInit(): void {
  
    this.service
      .getTrainers()
      .subscribe((trainers) => {
        console.log(trainers);
        this.trainers = trainers;
      });
      
  }

  refresh() {
    window.location.reload();
  }

  addNew(): void {
   this.router.navigateByUrl('/add-trainer');
  }

  // editItem(item : number): void {
  //   this.router.navigate(['update-trainer', item]);
  // }

  deleteItem(item : number): void {
    console.log(item);
    this.service.deleteTrainer(item).subscribe(
      data => {
       this.refresh();

      },
      
      err => {
        this.errorMessage = err.message;
        alert(this.errorMessage);
      }
    );
  }
 
}
