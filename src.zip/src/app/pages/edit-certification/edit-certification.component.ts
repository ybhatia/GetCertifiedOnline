import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Certification } from 'src/app/models/certifcation';
import { Trainer } from 'src/app/models/trainer';
import { CertificationService } from 'src/app/services/certification.service';

@Component({
  selector: 'app-edit-certification',
  templateUrl: './edit-certification.component.html',
  styleUrls: ['./edit-certification.component.css']
})
export class EditCertificationComponent implements OnInit {

  editForm: FormGroup;
  submitted = false;
  model: Certification;
  errorMessage: any;
  trainers: Trainer[];
  tra: Trainer;
  id: any;
  sDate:Date;
  eDate:Date;

  constructor(private formBuilder: FormBuilder, private service: CertificationService, 
    private router: Router, private route: ActivatedRoute) {
    this.model = new Certification;
    this.tra = new Trainer;
   }

  ngOnInit(): void {

    this.id = this.route.snapshot.params['id'];

    this.service.getCertification(this.id).subscribe(
      data => {
        console.log(data);
        this.model = Object.assign(data);
        // console.log(this.model.certificationCost);
        // console.log(this.model.startDate);
        this.tra = this.model.trainer;
        this.sDate=new Date(this.model.startDate);
        this.eDate=new Date(this.model.endDate);
        // console.log(this.tra);

      },
      err => {
        this.errorMessage = err.message;
        alert(this.errorMessage);
      }
    );
    

    this.service
      .getTrainer()
      .subscribe((trainers: any) => {
        this.trainers = trainers;
      });
     
  
    this.editForm = this.formBuilder.group({
      certificationName: ['', Validators.required],
      trainer: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      certificationCost: ['',Validators.required] 
  });
  
  }
  
  get f() { return this.editForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.model.certificationName = this.f.certificationName.value,
    this.model.trainer = this.f.trainer.value,
    this.model.startDate = this.f.startDate.value,
    this.model.endDate = this.f.endDate.value,
    this.model.certificationCost=this.f.certificationCost.value,
    this.service.updateCertification(this.model).subscribe(
      data => {
        this.model = data;
        this.router.navigateByUrl('/view-certification');
      }
    );
}

onReset() {
    this.submitted = false;
    this.editForm.reset();
    this.router.navigateByUrl('/view-certification');
}


}
