import { Feedback } from 'src/app/models/feedback';
import { Course } from 'src/app/models/course';
import { Trainer } from 'src/app/models/trainer';
import { Component, OnInit } from '@angular/core';
import { FeedbackServiceService } from '../../services/feedback-service.service';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';

@Component({
  selector: 'app-givefeedback',
  templateUrl: './givefeedback.component.html',
  styleUrls: ['./givefeedback.component.css']
})
export class GivefeedbackComponent implements OnInit {

  addForm: FormGroup;
  model: Feedback;
  submitted = false;
  errorMessage: any;
  isSuccessful: boolean;
  trainers: Trainer[];
  courses: Course[];


  constructor(private formBuilder: FormBuilder, private service: FeedbackServiceService, private router: Router) {
    this.model = new Feedback();
  }


  ngOnInit(): void {

    this.addForm = this.formBuilder.group({
      commSkill: ['', [Validators.required]],
      doubtClarity: ['', [Validators.required]],
      timeMgmt: ['', [Validators.required]],
      studyMaterial: ['', [Validators.required]],
      comment: [''],
      course: ['', [Validators.required]],
      trainer: ['', [Validators.required]]
    });

    this.service
      .getTrainer()
      .subscribe((trainers: any) => {
        this.trainers = trainers;
      });

    this.service
      .getCourses()
      .subscribe((courses: any) => {
        this.courses = courses;
      });

  }


  get f() { return this.addForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.model.trainer = this.f.trainer.value,
      this.model.course = this.f.course.value,
      this.model.commSkill = this.f.commSkill.value,
      this.model.doubtClarity = this.f.doubtClarity.value,
      this.model.timeMgmt = this.f.timeMgmt.value,
      this.model.studyMaterial = this.f.studyMaterial.value,
      this.model.comment = this.f.comment.value;
    console.log(this.model.comment);

    this.service.giveFeedback(this.model).subscribe(
      data => {
        this.model = data;
        console.log(data);
        this.isSuccessful = true;
        this.router.navigateByUrl('/home');
      }
    );

  }



}
