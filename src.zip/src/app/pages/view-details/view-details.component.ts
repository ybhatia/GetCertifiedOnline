import { Reminder } from './../../models/Reminder';
import { CertificationExam } from './../../models/CertificationExam';
import { Training } from './../../models/Training';
import { Student } from './../../models/Student';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AdminSupportService } from 'src/app/services/admin-support.service';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {

  student: Student[];
  training: Training[];
  exam: CertificationExam[];
  reminder: Reminder;

  viewReport = new FormGroup({
    studentId: new FormControl('', Validators.required)
  })

  constructor(
    private adminService: AdminSupportService
  ) { }

  ngOnInit(): void {
    document.getElementById('studentTable').style.display = "none";
    document.getElementById('examTable').style.display = "none";
  }

  viewReports() {
    this.training = [];
    this.adminService.getAllStudentDetails()
      .subscribe(data => {
        console.log("true");
        this.student = data;
      });
    this.adminService.getAllTrainingDetails()
      .subscribe(data => {
        console.log("true");
        this.training = data;
      });
    document.getElementById("studentTable").style.display = "block";
  }

  viewExamReports() {

    this.adminService.getAllExamDetails()
      .subscribe(data => {
        console.log("true");
        this.exam = data;
      });


    document.getElementById("examTable").style.display = "block";
  }

  sendMail(student: Student, examDate : any){
      
      //  this.reminder.studentName = student.studentFirstName;
      //  this.reminder.emailId = student.studentEmail;
      //  this.reminder.message = "Your exam is Near!!!";
      //  console.log(this.reminder);
       this.adminService.sendEmail(new Reminder(student.studentFirstName,student.studentEmail, "Your Exam is scheduled on ", examDate)).subscribe(data => {
         console.log("sent");
       })
  }
}
