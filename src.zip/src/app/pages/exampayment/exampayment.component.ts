import { PaymentService } from './../../services/payment.service';
import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-exampayment',
  templateUrl: './exampayment.component.html',
  styleUrls: ['./exampayment.component.css']
})
export class ExampaymentComponent implements OnInit {
 
message:string;
  constructor(private paymentservice:PaymentService) { }

  ngOnInit(): void {
  }

  exampayment(form:NgForm){
    console.log("*****************************")
    this.paymentservice.postexamPayment(form.value).subscribe(response =>{
   
      console.log(response);
      if(!response.error){
        this.message='Payment done successfully';
        setTimeout( ()=>{
          this.message = null; 
         },5000);
      }
      
      form.reset();
    });
  }
  onSubmit(){
    
  }

}
