import { Course } from 'src/app/models/course';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-view-course',
  templateUrl: './view-course.component.html',
  styleUrls: ['./view-course.component.css']
})
export class ViewCourseComponent implements OnInit {

  displayedColumns = ['id', 'courseName','actions'];
  model: Course;
 courses: Course[];
  dataSource : Course[];
  errorMessage: any;
  

  constructor(private router: Router, private service : CourseService) {
    this.model = new Course;
  }

  ngOnInit(): void {
    // this.service
    //   .getTrainers()
    //   .subscribe((trainers: any) => {
    //     this.trainers = this.trainers;
    //   });

    //   // this.service
    //   // .getCourses()
    //   // .subscribe((courses: any) => {
    //   //   this.courses = courses;
    //   // });
    this.service
      .getCourses()
      .subscribe((courses: any) => {
        this.dataSource = courses;
      });
      
  }

  refresh() {
    window.location.reload();
  }

  addNew(): void {
   this.router.navigateByUrl('/add-course');
  }

  // editItem(item : number): void {
  //   this.router.navigate(['update-course', item]);
  // }

  deleteItem(item : number): void {
    this.service.deleteCourse(item).subscribe(
      data => {
        console.log(data);
       this.refresh();

      },
      
      err => {
        this.errorMessage = err.message;
        alert(this.errorMessage);
      }
    );
  }
    

//}
// course: Course[];
//   trainer: Trainer[];

//   viewCourse = new FormGroup({
//     courseId: new FormControl('', Validators.required)
//   })

//   constructor(
//     private courseService: CourseService
//   ) { }

//   ngOnInit(): void {

//     document.getElementById('courseTable').style.display = "none";
//     //document.getElementById('examTable').style.display = "none";
//   }

//   viewCourses() {
//     this.trainer = [];
//     this.courseService.getCourses()
//       .subscribe(data => {
//         console.log("true");
//         this.course = data;
//       });
//     document.getElementById("courseTable").style.display = "block";
//   }
//   deleteCourse(item:number):void{
//     this.courseService.deleteCourse(item ).subscribe(
//      data => {
//        console.log(data);
//        window.location.reload;
//      } 
//     )
//   }
}

