import { Trainer } from 'src/app/models/trainer';
import { Course } from 'src/app/models/course';
import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { ActivatedRoute, Router} from '@angular/router'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit {

  addForm: FormGroup;
  model: Course;
  submitted = false;
  errorMessage: any;
  isSuccessful: boolean;
  isAddFailed: boolean;
  trainers: Trainer[];
  courses: Course[];

  constructor(private formBuilder: FormBuilder, private service: CourseService, private router: Router) {
    this.model = new Course();
  }

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      courseName: ['', Validators.required],
    });

    // this.service
    //   .getTrainers()
    //   .subscribe((trainers: any) => {
    //     this.trainers = trainers;
    //   });

    //   this.service
    //   .getCourses()
    //   .subscribe((courses: any) => {
    //     this.courses = courses;
    //   });
  }

  get f() { return this.addForm.controls; }

  onReset() {
    this.submitted = false;
    this.addForm.reset();
    this.router.navigateByUrl('/view-course');
  }

  onSubmit() {
    this.submitted = true;
    this.model.courseName = this.f.courseName.value,
    

    this.service.addCourse(this.model).subscribe(
      data => {
        console.log(data);
        this.model = data;
        this.isSuccessful = true;
       this.router.navigateByUrl('/view-course');
      }
    );
  }

}