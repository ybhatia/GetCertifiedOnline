import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
//import { UserHomeComponent } from '../user-home/user-home.component';
import { Role } from 'src/app/models/role.enum';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { TokenStorageService } from 'src/app/services/token-storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  loading = false;
  returnUrl: string;
  form: any = {};
  errorMessage = '';
  roles: string[] = [];	
  errors=null;


  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private tokenStorage:TokenStorageService) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      logUserName: ['', [Validators.required]],
      logPassword: ['', [Validators.required]],
    });


    if (this.tokenStorage.getToken) {
      this.roles = this.tokenStorage.getUser().roles;
    }
  }
  get loginFormControl() {
    return this.loginForm.controls;
  }
  onSubmit() {

    this.submitted = true;
    this.authenticationService.login(
      this.loginForm.value.logUserName,
      this.loginForm.value.logPassword)
      .subscribe((data) => {
        this.tokenStorage.saveToken(data.token);
        this.tokenStorage.saveRoles(data.authorityList);
        this.tokenStorage.setAuthenticated();
        this.redirectTo();
      },
        err => {
	        this.errors=err;
          this.errorMessage = err.error.message;
        }
      );
  }
  
  redirectTo(){
    if(this.tokenStorage.isLoggedIn)
    {
      if(this.tokenStorage.getRoles.indexOf('ADMIN')>-1){
        this.router.navigateByUrl('/home');
        //window.location.reload();
      }
      
      else{
      this.router.navigateByUrl('/home');
      //window.location.reload();
    }
    }
  }
  }





