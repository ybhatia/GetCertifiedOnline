import { TokenStorageService } from './../../services/token-storage.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  showAdminBoard = false;
  showUserBoard = false;
  userName : any;

  constructor(private router:Router ,private tokenStorageService: TokenStorageService) { }

  ngOnInit(): void {

    if (this.tokenStorageService.isLoggedIn) {
      // const user = this.tokenStorageService.getUser();
      // this.roles = user.roles;
      this.showAdminBoard = this.tokenStorageService.getRoles.includes('ADMIN');
      this.showUserBoard = this.tokenStorageService.getRoles.includes('USER');
       this.userName = this.tokenStorageService.getUser;
    }
  }
  logout() {
    this.tokenStorageService.signOut();

    this.router.navigateByUrl('/login');
  //  window.location.reload();
  }

  // logout() {
  //   window.location.reload();
  // }

  public get isLoggedIn(){
    return this.tokenStorageService.isLoggedIn;
}

  navigateToWebsite(){
    document.location.href = "https://capgemini.com"
}
}
