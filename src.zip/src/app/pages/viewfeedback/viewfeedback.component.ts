// import { Component, OnInit } from '@angular/core';
// import { FeedbackServiceService} from '../../services/feedback-service.service';
// import { Feedback } from '../../models/feedback'
// import { FormGroup } from '@angular/forms';
// import { Trainer } from 'src/app/models/trainer';
// import { Course } from 'src/app/models/course';

// @Component({
//   selector: 'app-viewfeedback',
//   templateUrl: './viewfeedback.component.html',
//   styleUrls: ['./viewfeedback.component.css']
// })
// export class ViewfeedbackComponent implements OnInit {

//   addForm: FormGroup;
//   model: Feedback;
//   submitted = false;
//   errorMessage: any;
//   isSuccessful: boolean;
//   trainers: Trainer[];
//   courses: Course[];
//   show: any;

//   constructor(private service: FeedbackServiceService ) { }

//   ngOnInit(): void {
//     let respo = this.service.allFeedback();
//     respo.subscribe(data => this.show= data);

//     this.service
//       .getTrainer()
//       .subscribe((trainers: any) => {
//         this.trainers = trainers;
//       });

//     this.service
//       .getCourses()
//       .subscribe((courses: any) => {
//         this.courses = courses;
//       });
//   }

//   get f() { return this.addForm.controls; }

// }


import { Component, OnInit, ViewChild } from '@angular/core';
import { FeedbackServiceService} from '../../services/feedback-service.service';
import { Feedback } from '../../models/feedback'
import { FormGroup } from '@angular/forms';
import { Trainer } from 'src/app/models/trainer';
import { Course } from 'src/app/models/course';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-viewfeedback',
  templateUrl: './viewfeedback.component.html',
  styleUrls: ['./viewfeedback.component.css']
})
export class ViewfeedbackComponent implements OnInit {

  displayedColumns: string[] = ['trainer', 'course', 'commSkill', 'doubtClarity',
                                 'timeMgmt', 'studyMaterial', 'comment'];

  model: Feedback;
  faculties: Trainer[];
  courses: Course[];
  dataSource : Feedback[];
  errorMessage: any;

  constructor(private router: Router, private service: FeedbackServiceService ) {
    this.model = new Feedback;
   }
   
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  // @ViewChild(MatSort) sort: MatSort;

  // ngAfterViewInit() {
  //   this.dataSource.paginator = this.paginator;
  //   this.dataSource.sort = this.sort;
  // }

  ngOnInit(): void {
    this.service
      .getTrainer()
      .subscribe((faculties: any) => {
        this.faculties = faculties;
      });

      this.service
      .getCourses()
      .subscribe((courses: any) => {
        this.courses = courses;
      });

    this.service
      .allFeedback()
      .subscribe((certifications: any) => {
        this.dataSource = certifications;
      });

  }
  refresh() {
    window.location.reload();
  }

  // applyFilter(event: Event) {
  //   const filterValue = (event.target as HTMLInputElement).value;
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // } 


}
