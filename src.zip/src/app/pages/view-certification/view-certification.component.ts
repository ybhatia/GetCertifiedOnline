import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Certification } from 'src/app/models/certifcation';
import { Course } from 'src/app/models/course';
import { Trainer } from 'src/app/models/trainer';
import { CertificationService } from 'src/app/services/certification.service';

@Component({
  selector: 'app-view-certification',
  templateUrl: './view-certification.component.html',
  styleUrls: ['./view-certification.component.css']
})
export class ViewCertificationComponent implements OnInit {

  displayedColumns = ['id', 'certificationName', 'trainerName', 'courseName', 'startDate', 'endDate', 'certificationCost', 'actions'];
  model: Certification;
  faculties: Trainer[];
  courses: Course[];
  dataSource : Certification[];
  errorMessage: any;
  

  constructor(private router: Router, private service : CertificationService) {
    this.model = new Certification;
  }

  ngOnInit(): void {
    this.service
      .getTrainer()
      .subscribe((faculties: any) => {
        this.faculties = faculties;
      });

      this.service
      .getCourses()
      .subscribe((courses: any) => {
        this.courses = courses;
      });
    this.service
      .getCertifications()
      .subscribe((certifications: any) => {
        this.dataSource = certifications;
      });
      
  }

  refresh() {
    window.location.reload();
  }

  addNew(): void {
    this.router.navigateByUrl('/add-certification');
  }

  editItem(item : number): void {
    this.router.navigate(['/edit-certification', item]);
  }

  deleteItem(item : number): void {
    this.service.deleteCertification(item).subscribe(
      data => {
        console.log(data);
       this.refresh();
      },
      err => {
        this.errorMessage = err.message;
        alert(this.errorMessage);
      }
    );
  }

}
