import { Trainer } from 'src/app/models/trainer';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TrainerService } from 'src/app/services/trainer.service';


@Component({
  selector: 'app-add-trainer',
  templateUrl: './add-trainer.component.html',
  styleUrls: ['./add-trainer.component.css']
})
export class AddTrainerComponent implements OnInit {

  addForm: FormGroup;
  model: Trainer;
  submitted = false;
  errorMessage: any;
  isSuccessful: boolean;
  isAddFailed: boolean;
  trainers: Trainer[];

  constructor(private formBuilder: FormBuilder, private service: TrainerService, private router: Router) {
    this.model = new Trainer();
  }

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      trainerName: ['', Validators.required],
      trainerSkill:['', Validators.required]
    });
  }
    get f() { return this.addForm.controls; }

    onReset() {
      this.submitted = false;
      this.addForm.reset();
      this.router.navigateByUrl('/view-trainer');
    }
  
    onSubmit() {
      this.submitted = true;
       this.model.trainerName = this.f.trainerName.value,
       this.model.trainerSkill = this.f.trainerSkill.value,
      //this.model = this.addForm.value;
      
  
      this.service.addTrainer(this.model).subscribe(
        data => {
          this.model = data;
          this.isSuccessful = true;
         this.router.navigateByUrl('/view-trainer');
        }
      );
    }
  
  }
