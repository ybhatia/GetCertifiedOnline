import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Certification } from 'src/app/models/certifcation';
import { Course } from 'src/app/models/course';
import { Trainer } from 'src/app/models/trainer';
import { CertificationService } from 'src/app/services/certification.service';

@Component({
  selector: 'app-add-certification',
  templateUrl: './add-certification.component.html',
  styleUrls: ['./add-certification.component.css']
})
export class AddCertificationComponent implements OnInit {
  addForm: FormGroup;
  model: Certification;
  submitted = false;
  errorMessage: any;
  isSuccessful: boolean;
  isAddFailed: boolean;
  trainers: Trainer[];
  courses: Course[];

  constructor(private formBuilder: FormBuilder, private service: CertificationService, 
    private router: Router) {
    this.model = new Certification();
  }

  ngOnInit(): void {
    this.addForm = this.formBuilder.group({
      certificationName: ['', [Validators.required,Validators.pattern(/^([A-Z][a-z]*((\s[A-Za-z])?[a-z]*)*)$/)]],
      course: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]],
      certificationCost: ['',[Validators.required, Validators.pattern(/^[0-9]+$/),]]
    });

    this.service
      .getTrainer()
      .subscribe((trainers: any) => {
        this.trainers = trainers;
      });

      this.service
      .getCourses()
      .subscribe((courses: any) => {
        this.courses = courses;
      });
  }

  get f() { return this.addForm.controls; }

  onReset() {
    this.submitted = false;
    this.addForm.reset();
    this.router.navigateByUrl('/view-certification');
  }

  onSubmit() {
    this.submitted = true;
    this.model.certificationName = this.f.certificationName.value,
    this.model.trainer = this.f.trainer.value,
    this.model.course = this.f.course.value,
    this.model.startDate = this.f.startDate.value,
    this.model.endDate = this.f.endDate.value
    this.model.certificationCost=this.f.certificationCost.value;
    this.service.addCertification(this.model
      // new Certification(
      // // this.f.certificationName.value,
      // // this.f.course.value,
      // // this.f.trainer.value,
      // // this.f.startDate.value,
      // // this.f.endDate.value,
      // // this.f.certificationCost.value,
      // this.addForm.value.certificationName,
    ).subscribe(
      data => {
        this.model = data;
        this.isSuccessful = true;
        this.router.navigateByUrl('/view-certification');
      }
    );
  }

}
