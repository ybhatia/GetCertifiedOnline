import { PaymentService } from './../../services/payment.service';
import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-trainingpayment',
  templateUrl: './trainingpayment.component.html',
  styleUrls: ['./trainingpayment.component.css']
})
export class TrainingpaymentComponent implements OnInit {
 
message:string;
  constructor(private paymentservice:PaymentService) { }

  ngOnInit(): void {
  }

  trainingpayment(form: NgForm){
    console.log("*****************************")
    this.paymentservice.postTrainingPayment(form.value).subscribe(response =>{
      console.log(response);
      if(!response.error){
        this.message='Payment done successfully';
        setTimeout( ()=>{
          this.message = null; 
         },5000);
      }
      
      form.reset();
    });
  }

}
