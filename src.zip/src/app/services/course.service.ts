import { Course } from 'src/app/models/course';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


const AUTH_API = 'http://localhost:1111/course';
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  
@Injectable({
  providedIn: 'root'
})
export class CourseService {

//   private baseUrl = 'http://localhost:8080/springboot-crud-rest/api/v1/employees';

//   constructor(private http: HttpClient) { }

//   getCourse(courseId: number): Observable<any> {
//     return this.http.get(`${this.baseUrl}/${courseId}`);
//   }

//   addCourse(course: Object): Observable<Object> {
//     return this.http.post(`${this.baseUrl}`, course);
//   }

//   updateCourse(courseId: number, value: any): Observable<Object> {
//     return this.http.put(`${this.baseUrl}/${courseId}`, value);
//   }

//   deleteCourse(courseId: number): Observable<any> {
//     return this.http.delete(`${this.baseUrl}/${courseId}`, { responseType: 'text' });
//   }

//   getCoursesList(): Observable<any> {
//     return this.http.get(`${this.baseUrl}`);
//   }
//   getTrainer(trainerId: number): Observable<any> {
//     return this.http.get(`${this.baseUrl}/${trainerId}`);
//   }

//   addTrainer(trainer: Object): Observable<Object> {
//     return this.http.post(`${this.baseUrl}`, trainer);
//   }

//   updateTrainer(trainerId: number, value: any): Observable<Object> {
//     return this.http.put(`${this.baseUrl}/${trainerId}`, value);
//   }

//   deleteTrainer(trainerId: number): Observable<any> {
//     return this.http.delete(`${this.baseUrl}/${trainerId}`, { responseType: 'text' });
//   }
constructor(private http: HttpClient) { }

  addCourse(course : Course):Observable<any> {
    return this.http.post(AUTH_API + '/addcourse',{
      courseName : course.courseName,
      // courseId : course.courseId
    },httpOptions);
 }

 

 deleteCourse(courseId):Observable<any> {
  return this.http.delete(AUTH_API + `/delete/${courseId}`, { responseType: 'json' });
}

// getTrainings(): Observable<any> {
//   return this.http.get(AUTH_API, { responseType: 'json' })
// }

getCourses(): Observable<any> {
 return this.http.get(AUTH_API + '/allcourses', { responseType: 'json' })
}

getTrainers(): Observable<any> {
  return this.http.get(AUTH_API + '/alltrainers', { responseType: 'json' })
}

}
