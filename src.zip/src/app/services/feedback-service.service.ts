import { Trainer } from 'src/app/models/trainer';
import { Course } from 'src/app/models/course';
import { Feedback } from 'src/app/models/feedback';

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


const BASE_URL = 'http://localhost:1112/feedback';

const httpOptions = {​​​​​​​
  headers: new HttpHeaders({​​​​​​​ 'Content-Type': 'application/json' }​​​​​​​)
}​​​​​​​;

@Injectable({
  providedIn: 'root'
})

export class FeedbackServiceService {

  constructor(private http: HttpClient) { }

  giveFeedback(feedback: Feedback): Observable<any> {
    return this.http.post(BASE_URL + `/addfeedback`, {
      commSkill: feedback.commSkill,
      doubtClarity: feedback.doubtClarity,
      timeMgmt: feedback.timeMgmt,
      studyMaterial: feedback.studyMaterial,
      comment: feedback.comment,
      trainerId: feedback.trainer.id,
      courseId: feedback.course.id,
    }, httpOptions);
  }

  public allFeedback() {
    return this.http.get(BASE_URL + `/allfeedback`);
  }

  getCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(BASE_URL + '/courses', { responseType: 'json' })
  }

  getTrainer(): Observable<any> {
    return this.http.get<Trainer[]>(BASE_URL + '/trainers', { responseType: 'json' })
  }

}
