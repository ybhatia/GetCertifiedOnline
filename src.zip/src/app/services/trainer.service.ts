import { Trainer } from 'src/app/models/trainer';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const baseUrl = 'http://localhost:1111/trainer';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})

export class TrainerService {


  constructor(private http: HttpClient) { }

  getTrainers(): Observable<any> {
    return this.http.get(baseUrl + '/alltrainers', { responseType: 'json' })
  }

  addTrainer(trainer : Trainer):Observable<any> {
    return this.http.post(baseUrl + '/addtrainer',{
      trainerName : trainer.trainerName,
      trainerSkill : trainer.trainerSkill
    },httpOptions);
 }

 deleteTrainer(trainerId):Observable<any> {
  return this.http.delete(baseUrl + `/delete/${trainerId}`, { responseType: 'json' });
}
}
