import { Reminder } from './../models/Reminder';
import { CertificationExam } from './../models/CertificationExam';
import { Training } from './../models/Training';
import { Student } from './../models/Student';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminSupportService {
  
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient: HttpClient) { }

  getStudentDetailsByStudentId(id : any): Observable<Student> {
    return this.httpClient.get<Student>("http://localhost:9090/adminSupport/studentDetailsByStudentId/"+ id, this.options);
  }

  getTrainingDetailsByStudentId(id : any): Observable<Training[]> {
    return this.httpClient.get<Training[]>("http://localhost:9090/adminSupport/trainingDetailsByStudentId/"+ id, this.options);
  }

  getAllStudentDetails(): Observable<Student[]> {
    return this.httpClient.get<Student[]>("http://localhost:9090/adminSupport/getAllStudentDetails", this.options);
  }

  getAllTrainingDetails(): Observable<Training[]> {
    return this.httpClient.get<Training[]>("http://localhost:9090/adminSupport/getAllTrainingDetails", this.options);
  }

  getAllExamDetails(): Observable<CertificationExam[]> {
    return this.httpClient.get<CertificationExam[]>("http://localhost:9090/adminSupport/getAllExamDetails", this.options);
  }

  sendEmail(reminder : Reminder){
    return this.httpClient.post<Reminder>("http://localhost:9090/adminSupport/sendEmail",JSON.stringify(reminder), this.options);
  }

}
