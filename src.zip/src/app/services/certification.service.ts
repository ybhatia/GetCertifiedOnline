import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Certification } from '../models/certifcation';
import { Course } from '../models/course';

const BASE_URL = 'http://localhost:5555/certification';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CertificationService {

  constructor(private http: HttpClient) { }

  addCertification(certification : Certification):Observable<any> {
    return this.http.post(BASE_URL+'/addcertification',
     {certificationName : certification.certificationName,
      startDate : certification.startDate,
      endDate : certification.endDate,
      trainerId : certification.trainer.id,
      courseId : certification.course.id,
      certificationCost : certification.certificationCost}
    // certification
    ,httpOptions);
 }

 updateCertification(certification : Certification):Observable<any> {
  return this.http.put(BASE_URL + `/update/${certification.id}`, {
    certificationName : certification.certificationName,
    startDate : certification.startDate,
    endDate : certification.endDate,
    trainerId : certification.trainer.id,
    certificationCost : certification.certificationCost,
  },httpOptions);
}

 deleteCertification(certificationId):Observable<any> {
  return this.http.delete(BASE_URL + `/delete/${certificationId}`, { responseType: 'json' });
}

getCertification(certificationId):Observable<any> {
  return this.http.get(BASE_URL + `/getbyid/${certificationId}`, { responseType: 'json' });
}

getCertifications(): Observable<any> { 
  return this.http.get(BASE_URL+'/certifications', { responseType: 'json' })
}

getCourses(): Observable<Course[]> {
 return this.http.get<Course[]>(BASE_URL + '/courses', { responseType: 'json' })
}

getTrainer(): Observable<any> {
  return this.http.get(BASE_URL + '/trainers', { responseType: 'json' })
}
}
