import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http: HttpClient) { 
    
  }
  myURL = 'http://localhost:9092/payment/';

  getPaymentData() {
    return this.http.get<any>(`${this.myURL}booksInfo`);
  }

  postexamPayment(payment) {
    return this.http.post<any>(`${this.myURL}exampayment`, payment);
  }

  postTrainingPayment(payment) {
    return this.http.post<any>(`${this.myURL}trainingpayment`, payment);
  }


}

