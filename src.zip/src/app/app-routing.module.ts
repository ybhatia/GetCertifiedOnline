import { ViewfeedbackComponent } from './pages/viewfeedback/viewfeedback.component';
import { GivefeedbackComponent } from './pages/givefeedback/givefeedback.component';
import { TrainingpaymentComponent } from './pages/trainingpayment/trainingpayment.component';
import { ExampaymentComponent } from './pages/exampayment/exampayment.component';
import { LoginComponent } from 'src/app/pages/login/login.component';
import { AddCourseComponent } from './pages/add-course/add-course.component';
import { ViewCourseComponent } from './pages/view-course/view-course.component';
import { ViewTrainerComponent } from './pages/view-trainer/view-trainer.component';
import { AddTrainerComponent } from './pages/add-trainer/add-trainer.component';
import { RegisterComponent } from './pages/register/register.component';
import { ViewCertificationComponent } from './pages/view-certification/view-certification.component';
import { EditCertificationComponent } from './pages/edit-certification/edit-certification.component';
import { AddCertificationComponent } from './pages/add-certification/add-certification.component';
import { ViewDetailsComponent } from './pages/view-details/view-details.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './pages/about/about.component';

const routes: Routes = [
  { component: AboutComponent, path: '' },
  { component: ViewDetailsComponent, path: 'view-details' },
  { component: ViewCourseComponent, path: 'view-course' },
  { component: AddCourseComponent, path: 'add-course' },
  { component: AddTrainerComponent, path: 'add-trainer' },
  { component: ViewTrainerComponent, path: 'view-trainer' },
  { component: AddCertificationComponent, path: 'add-certification' },
  { component: EditCertificationComponent, path: 'edit-certification/:id' },
  { component: ViewCertificationComponent, path: 'view-certification' },
  { component: LoginComponent, path: 'login' },
  { component: RegisterComponent, path: 'register' },
  { component: AboutComponent, path: 'home' },
  { component: ExampaymentComponent, path: 'exampayment' },
  { component: TrainingpaymentComponent, path: 'trainingpayment' },
  { component: GivefeedbackComponent, path: 'givefeedback' },
  { component: ViewfeedbackComponent, path: 'viewfeedback' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
