import { GivefeedbackComponent } from './pages/givefeedback/givefeedback.component';
import { ViewfeedbackComponent } from './pages/viewfeedback/viewfeedback.component';
import { TrainingpaymentComponent } from './pages/trainingpayment/trainingpayment.component';
import { ExampaymentComponent } from './pages/exampayment/exampayment.component';
import { ViewTrainerComponent } from './pages/view-trainer/view-trainer.component';
import { AddTrainerComponent } from './pages/add-trainer/add-trainer.component';
import { AddCourseComponent } from './pages/add-course/add-course.component';
import { ViewCourseComponent } from './pages/view-course/view-course.component';
import { EditCertificationComponent } from './pages/edit-certification/edit-certification.component';
import { ViewCertificationComponent } from './pages/view-certification/view-certification.component';
import { AddCertificationComponent } from './pages/add-certification/add-certification.component';
import { RegisterComponent } from './pages/register/register.component';
import { LoginComponent } from './pages/login/login.component';
import { HomeComponent } from './pages/home/home.component';

import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material/material.module';
import { ViewDetailsComponent } from './pages/view-details/view-details.component';
import { HttpClientModule } from '@angular/common/http';
import { AboutComponent } from './pages/about/about.component';



@NgModule({
  declarations: [
    AppComponent,
    ViewDetailsComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    AddCertificationComponent,
    ViewCertificationComponent,
    EditCertificationComponent,
    AboutComponent,
    ViewCourseComponent,
    AddCourseComponent,
    AddTrainerComponent,
    ViewTrainerComponent,
    ExampaymentComponent,
    TrainingpaymentComponent,
    ViewfeedbackComponent,
    GivefeedbackComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
