package com.cg.gco.authentication.validation;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@SpringBootTest
public class AuthenticationTestCase {
		
	    @Autowired
		Validation validation;

		@Test
		public void testCustomerCompleteNameWithDigits() 
		{
			boolean flag=validation.checkCustomerName("Soham1808");
			assertFalse(flag);	
		}
		@Test
		public void testCustomerCompleteNameConatinsSpecialChar() 
		{
			boolean flag=validation.checkCustomerName("Soham@Purohit");
			assertFalse(flag);	
		}
		@Test
		public void testCustomerCompleteNameConatinsOnlyDigits() 
		{
			boolean flag=validation.checkCustomerName("123456");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerCompleteNameConatinsNumberAndSpecialChar() 
		{
			boolean flag=validation.checkCustomerName("1234@");
			assertFalse(flag);	
		}
		
		
		@Test
		public void testIsValidPassWord() 
		{
			boolean flag=validation.checkPassword("Soham@1808");
			assertTrue(flag);	
		}
		@Test
		public void testIsValidPassWordContainsOnlyDigits() 
		{
			boolean flag=validation.checkPassword("988123");
			assertFalse(flag);	
		}
		@Test
		public void testIsValidPassWordContainsOnlyAlphabets() 
		{
			boolean flag=validation.checkPassword("abcdef");
			assertFalse(flag);	
		}
		@Test
		public void testIsValidPassWordContainsOnlyAlphabetsAndCharacters() 
		{
			boolean flag=validation.checkPassword("abcdef123");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerMobileNumber() 
		{
			boolean flag=validation.checkCustomerMobile("7865432167");
			assertTrue(flag);	
		}
		
		@Test
		public void testCustomerMobileNumberContainsCharacter() 
		{
			boolean flag=validation.checkCustomerMobile("786543216p");
			assertFalse(flag);	
		}
		@Test
		public void testCustomerMobileNumberContainsSpecialCharacter() 
		{
			boolean flag=validation.checkCustomerMobile("786543216@");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerMobileNumberContainsLessThanTenDigits() 
		{
			boolean flag=validation.checkCustomerMobile("78654321");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerEmail() 
		{
			boolean flag=validation.checkCustomerEmail("sp.user@gmail.com");
			assertTrue(flag);	
		}
		
		@Test
		public void testCustomerEmailDontHaveAtSymbol() 
		{
			boolean flag=validation.checkCustomerEmail("spgmail.com");
			assertFalse(flag);	
		}
		
		@Test
		public void testCustomerEmailDontHaveDotCom() 
		{
			boolean flag=validation.checkCustomerEmail("sp@gmail");
			assertFalse(flag);	
		}
		


	}
