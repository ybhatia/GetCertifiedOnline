package com.cg.gco.authentication.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


public class SignUpResponseDto {
	String msg;
	boolean success;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	@Override
	public String toString() {
		return "SignUpResponseDto [msg=" + msg + ", success=" + success + "]";
	}
	public SignUpResponseDto(String msg, boolean success) {
		super();
		this.msg = msg;
		this.success = success;
	}
	public SignUpResponseDto() {
		super();
	}
	
	
	
}



