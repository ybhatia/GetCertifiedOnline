package com.cg.gco.authentication.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.gco.authentication.dao.AuthUserRepository;
import com.cg.gco.authentication.dao.RolesRepository;
import com.cg.gco.authentication.dto.SignInFailResponseDto;
import com.cg.gco.authentication.dto.SignInResponseDto;
import com.cg.gco.authentication.dto.SignInUserDto;
import com.cg.gco.authentication.dto.SignUpFailResponseDto;
import com.cg.gco.authentication.dto.SignUpResponseDto;
import com.cg.gco.authentication.dto.SignUpUserDto;
import com.cg.gco.authentication.entity.AuthUser;
import com.cg.gco.authentication.entity.Role;
import com.cg.gco.authentication.entity.Roles;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@CrossOrigin("*")
@RequestMapping("/auth-service")
public class AuthController {
	
	@GetMapping("/")
	public String Home()
	{
		return  "Home Page For RequestStatus MicroService";
		
	}
	
	private  AuthUserRepository applicationUserRepository;
    private  RolesRepository rolesRepository;
    private  BCryptPasswordEncoder bCryptPasswordEncoder;
    
    
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    public AuthController(AuthUserRepository applicationUserRepository, RolesRepository rolesRepository,BCryptPasswordEncoder bCryptPasswordEncoder)
    {
        this.applicationUserRepository = applicationUserRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
        this.rolesRepository = rolesRepository;
    }
    
    
	
    @PostMapping("/signin")
    public ResponseEntity<?> signIn(@Valid @RequestBody SignInUserDto signInUserDTO) {

        try {
            UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                    signInUserDTO.getUserName(), signInUserDTO.getPassword(), Collections.emptyList());
            // 3. Authentication manager authenticate the user, and use UserDetialsServiceImpl::loadUserByUsername() method to load the user.
            Authentication authentication = this.authenticationManager.authenticate(authToken);

//        using this to fetch all authorities
            Collection<GrantedAuthority> authenticatedUserAuthorityList =
                    ((User) authentication.getPrincipal()).getAuthorities();
            Calendar c = Calendar.getInstance();
//        10 minute expiration period
            c.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH) + 10);
            String token = Jwts.builder()
                    .setExpiration(c.getTime())
                    .setSubject(((User) authentication.getPrincipal()).getUsername())
                    .claim("roles", authenticatedUserAuthorityList)
                    .setIssuer("gco")
                    .signWith(SignatureAlgorithm.HS512, "secure").compact();
            return ResponseEntity.status(200).body(new SignInResponseDto(token, true, authenticatedUserAuthorityList));

        } catch (AuthenticationException e) {
            return ResponseEntity.status(401).body(new SignInFailResponseDto(false, e.getMessage()));
        }

    }

    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@Valid @RequestBody SignUpUserDto signUpUserDto) {
        try {
            if(applicationUserRepository.existsByUserName(signUpUserDto.getUserName())){
                return ResponseEntity.badRequest().body("Error: Email is already in use!");
            }
            AuthUser authUser = new AuthUser();
            authUser.setPassword(bCryptPasswordEncoder.encode(signUpUserDto.getPassword()));
            authUser.setUserName(signUpUserDto.getUserName());
            authUser.setName(signUpUserDto.getName());
            authUser.setEmail(signUpUserDto.getEmail());
            authUser.setPhoneNumber(signUpUserDto.getPhoneNumber());
            List<Roles> rolesList = new ArrayList<>();
            rolesList.add(new Roles(Role.USER));
            rolesRepository.saveAll(rolesList);
            authUser.setRolesList(rolesList);
            applicationUserRepository.save(authUser);
            return ResponseEntity.ok(new SignUpResponseDto("User Registration Successful",true));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new SignUpFailResponseDto(e.getMessage(),false));
        }


    }
	 
    

}
