package com.cg.gco.authentication.dto;




public class SignInFailResponseDto {
	private boolean success;
	private String msg;
	
	
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public SignInFailResponseDto(boolean success, String msg) {
		super();
		this.success = success;
		this.msg = msg;
	}
	public SignInFailResponseDto() {
		super();
	}
	@Override
	public String toString() {
		return "SignInFailResponseDto [success=" + success + ", msg=" + msg + "]";
	}
	
	
	
	
	
	
}





