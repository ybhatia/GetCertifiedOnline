package com.cg.gco.authentication.entity;

public enum Role {
    ADMIN,
    USER
}
