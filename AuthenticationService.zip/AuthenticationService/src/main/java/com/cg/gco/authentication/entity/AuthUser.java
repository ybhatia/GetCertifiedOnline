package com.cg.gco.authentication.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity

@Table(name = "AuthUser", uniqueConstraints = { @UniqueConstraint(columnNames = "userName") })
public class AuthUser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="userName")
	@NotEmpty(message = "Please Enter User Name")
	private String userName;
	
	@Column(name ="phoneNumber")
	@NotNull(message = "Please Enter Contact Number")
	private long phoneNumber;
	
	
	  @NotEmpty(message = "Please Enter Email") 
	  @Email 
	  private String email;
	 
	
	@NotEmpty(message = "Please Enter Name")
	private String name;
	
	@NotEmpty(message = "Please Enter Password")
	private String password;

	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,targetEntity = Roles.class)
	List<Roles> rolesList;


	@Override
	public String toString() {
		return "AuthUser [id=" + id + ", userName=" + userName + ", phoneNumber=" + phoneNumber + ", email=" + email
				+ ", name=" + name + ", password=" + password + ", rolesList=" + rolesList + "]";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
	  public String getEmail() 
	  { return email; }
	  
	  public void setEmail(String email) 
	  { this.email = email; }
	 

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Roles> getRolesList() {
		return rolesList;
	}

	public void setRolesList(List<Roles> rolesList) {
		this.rolesList = rolesList;
	}


	public AuthUser(long id, @NotEmpty(message = "Please Enter User Name") String userName,
			@NotNull(message = "Please Enter Contact Number") long phoneNumber,
			@NotEmpty(message = "Please Enter Email") @Email String email,
			@NotEmpty(message = "Please Enter Name") String name,
			@NotEmpty(message = "Please Enter Password") String password, List<Roles> rolesList) {
		super();
		this.id = id;
		this.userName = userName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.name = name;
		this.password = password;
		this.rolesList = rolesList;
	}

	public AuthUser() {
		super();
	}
	
	

}
