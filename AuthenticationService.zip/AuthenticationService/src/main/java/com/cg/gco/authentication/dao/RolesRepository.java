package com.cg.gco.authentication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.gco.authentication.entity.Roles;

public interface RolesRepository extends JpaRepository<Roles, Long> {

}
