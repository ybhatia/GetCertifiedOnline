package com.cg.gco.authentication.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


public class SignInUserDto {

	@NotNull(message = "Please Enter User Name")
	private String userName;

	@NotEmpty(message = "Please Enter Password")
	private String password;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SignInUserDto [userName=" + userName + ", password=" + password + "]";
	}

	public SignInUserDto(@NotNull(message = "Please Enter User Name") String userName,
			@NotEmpty(message = "Please Enter Password") String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	public SignInUserDto() {
		super();
	}
	
	
	
}


