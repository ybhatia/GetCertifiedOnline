package com.cg.gco.authentication.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cg.gco.authentication.dao.AuthUserRepository;
import com.cg.gco.authentication.entity.AuthUser;


@Service
public class AuthUserService implements UserDetailsService{

	private final AuthUserRepository authUserRepository;
	@Autowired
	public AuthUserService(AuthUserRepository authUserRepository){
		this.authUserRepository=authUserRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<AuthUser> optionalAuthUser=authUserRepository.findByUserName(username);

		if(optionalAuthUser.isPresent()){
			AuthUser authUser=optionalAuthUser.get();
			List<String>rolesArray=authUser.getRolesList().stream().map((roles -> roles.getRole().name())).collect(Collectors.toList());

			List<GrantedAuthority> authorityList=AuthorityUtils.commaSeparatedStringToAuthorityList(String.join(",",rolesArray));
			return new User(authUser.getUserName(),authUser.getPassword(),authorityList);
		}
		throw new UsernameNotFoundException("not found");


	}

}
