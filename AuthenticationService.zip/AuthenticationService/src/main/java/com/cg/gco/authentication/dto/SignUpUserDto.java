package com.cg.gco.authentication.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;




public class SignUpUserDto {
	@NotEmpty(message = "PLease Enter User Name ")
	private String userName;

	@NotNull(message = "Please Enter Phone Number")    
	private long phoneNumber;

	@NotEmpty(message = "Please Enter  Name")
	private String name;

	@NotEmpty(message = "Please Enter Password")
	private String password;

	@NotEmpty(message = "Please Enter Email")
	@Email 
	private String email;
	
	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public SignUpUserDto(@NotEmpty(message = "Please Enter Email") @Email String email,
	@NotEmpty(message = "PLease Enter User Name ") String userName,
			@NotNull(message = "Please Enter Phone Number") long phoneNumber,
			@NotEmpty(message = "Please Enter  Name") String name,
			@NotEmpty(message = "Please Enter Password") String password)
			 {
		super();
		this.email = email;
		this.userName = userName;
		this.phoneNumber = phoneNumber;
		this.name = name;
		this.password = password;
		
	}

	public SignUpUserDto() {
		super();
	}

	@Override
	public String toString() {
		return "SignUpUserDto [userName=" + userName + ", phoneNumber=" + phoneNumber + ", name=" + name + ", password="
				+ password + ", email=" + email + "]";
	}

	


}



