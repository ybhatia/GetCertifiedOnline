package com.cg.gco.authentication.dto;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class SignInResponseDto {
	private String token;
	private boolean success;
	private Collection<GrantedAuthority> authorityList;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public Collection<GrantedAuthority> getAuthorityList() {
		return authorityList;
	}
	public void setAuthorityList(Collection<GrantedAuthority> authorityList) {
		this.authorityList = authorityList;
	}
	public SignInResponseDto(String token, boolean success, Collection<GrantedAuthority> authorityList) {
		super();
		this.token = token;
		this.success = success;
		this.authorityList = authorityList;
	}
	public SignInResponseDto() {
		super();
	}
	@Override
	public String toString() {
		return "SignInResponseDto [token=" + token + ", success=" + success + ", authorityList=" + authorityList + "]";
	}
	
	
}



